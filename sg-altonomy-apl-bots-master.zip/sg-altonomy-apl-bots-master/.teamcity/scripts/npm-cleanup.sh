#!/bin/bash

# exit when any command fails
set -e

rm -rf dist node_modules
