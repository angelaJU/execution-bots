CREATE TABLE `service` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `service_type_id` int DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `end_time` datetime(6) DEFAULT NULL,
  `account_id` int DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `config_key` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_id` (`account_id`),
  KEY `service_type_id` (`service_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1425563012
    DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE `service_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1525563012
    DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO Altonomy.service_type
(id, name)
VALUES(7, 'legacy bot');

CREATE TABLE `exchange` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `modulename` varchar(255) NOT NULL,
  `classname` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=81005
    DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;


INSERT INTO Altonomy.exchange
(id, name, modulename, classname)
VALUES(2, 'BINANCE', 'Binance', 'Binance');

CREATE TABLE `account` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  `exchange_id` int DEFAULT NULL,
  `access` varchar(1024) NOT NULL,
  `private` varchar(8000) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  KEY `exchange_id` (`exchange_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61005
    DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO Altonomy.account
(id, name, exchange_id, access, private)
VALUES(1135, 'QUANT_BINANCE_25', 2, '123', '456');
