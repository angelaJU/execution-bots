import logging
import random
from datetime import datetime
from types import SimpleNamespace
from typing import Callable, Iterable, List, NewType, Tuple, NamedTuple
from uuid import uuid4

from altonomy.core.OrderBook import LegacyOrderBook, OrderBook

import altonomy.apl_bots.VolumeBot as VolumeBot
import pytest
from altonomy.exchanges import Order

Price = NewType('Price', float)
Amount = NewType('Amount', float)
PriceLevel = NewType('PriceLevel', Tuple[Price, Amount])
Asks = NewType('Asks', Iterable[PriceLevel])
Bids = NewType('Bids', Iterable[PriceLevel])


class PlacedOrder(NamedTuple):
    side: str
    pair: str
    price: float
    amount: float
    order_id: int


class FakeBroker:
    class Orderbook(NamedTuple):
        asks: Iterable
        bids: Iterable

    def __init__(self, pair, initial_orderbook: Tuple[Asks, Bids]):
        self.pair = pair
        self._orderbook = FakeBroker.Orderbook(
            sorted(initial_orderbook[0]), sorted(initial_orderbook[1], reverse=True),
        )
        self.orderbook_mutations = [lambda x: x]
        self.orders_placed = []
        self.orders_canceled = []
        self.order_results = {}

        self.client = SimpleNamespace()
        self.client.buy_wait = self.buy_wait
        self.client.sell_wait = self.sell_wait
        self.client.get_order_details = self.client_order_details
        self.client.cancel_wait = self.cancel_wait
        self.client.buy = self.buy
        self.client.sell = self.sell
        self.client.cancel = self.cancel

        self.exchange = SimpleNamespace()
        self.exchange.Order = Order.Order

    def add_orderbook_mutation(
        self, mutation: Callable[[Tuple[Asks, Bids]], Tuple[Asks, Bids]]
    ):
        self.orderbook_mutations.append(mutation)

    def update_orderbook(self):
        try:
            mutation = self.orderbook_mutations.pop(0)
            self._orderbook = mutation(self._orderbook)
        except IndexError:
            pass

    @property
    def orderbook(self):
        ob = LegacyOrderBook(
            {
                self.pair: {
                    'asks': [
                        {'price': p, 'volume': v} for p, v in sorted(self._orderbook[0])
                    ],
                    'bids': [
                        {'price': p, 'volume': v}
                        for p, v in sorted(self._orderbook[1], reverse=True)
                    ],
                }
            }
        )
        print(f'returned orderbook {ob}')
        return ob

    def buy_wait(self, pair, price, amount):
        print(f'placed buy order {pair} {price} {amount}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder('B', pair, price, amount, order_id))
        return [order_id, {'state': 'success',}]

    def buy(self, pair, price, amount):
        print(f'placed buy order {pair} {price} {amount}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder('B', pair, price, amount, order_id))
        return order_id

    def sell_wait(self, pair, price, amount):
        print(f'placed sell order {pair} {price} {amount}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder('S', pair, price, amount, order_id))
        return [order_id, {'state': 'success',}]

    def sell(self, pair, price, amount):
        print(f'placed sell order {pair} {price} {amount}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder('S', pair, price, amount, order_id))
        return order_id

    def cancel_wait(self, order_id):
        print(f'cancel order {order_id}')
        self.orders_canceled.append(order_id)

    def cancel(self, order_id):
        print(f'cancel order {order_id}')
        self.orders_canceled.append(order_id)

    def client_order_details(
        self, _=None, __=None, order_id=None,
    ):
        side, pair, price, amount, order_id = next(
            order for order in self.orders_placed if order[4] == order_id
        )

        od = {
            'order_ref': order_id,
            'pair': pair,
            'side': side,
            'price': price,
            'amount': amount,
            **self.order_results.get(order_id, {}),
        }
        print(f'retrieved order details {od}')
        return od


@pytest.fixture(autouse=True)
def set_log_cap_level(caplog):
    caplog.set_level(logging.DEBUG)


@pytest.fixture
def broker():
    return FakeBroker(
        'ABCXYZ',
        ([(i, 1000) for i in range(30, 40)], [(i, 1000) for i in range(10, 21)]),
    )


@pytest.fixture
def vb(monkeypatch, broker):
    monkeypatch.setattr(random, 'choice', lambda s: s[0])
    monkeypatch.setattr(random, 'triangular', lambda a, b, c: c)
    monkeypatch.setattr(random, 'uniform', lambda a, b: min(a, b))
    monkeypatch.setattr(VolumeBot.VolumeBot, '__init__', value=lambda *x: None)
    vb = VolumeBot.VolumeBot()
    vb.minimumticksize = 1
    vb.orderpricerounding = 0
    vb.orderwaitingtime = 0
    vb.internal_wait_time = 0
    vb.position = {}
    vb.max_altcoin_imbalance = -1
    vb.max_quotecoin_imbalance = -1
    vb._safe_size = None
    vb.logger = logging.getLogger()
    vb.brokers = [broker]
    vb.tradingpair = 'ABCXYZ'
    vb.probe_mode = False
    monkeypatch.setattr(vb, 'update_order_book_meaningfully', broker.update_orderbook)
    return vb


def test_eat_own_order(monkeypatch, vb, broker):
    # change the orderbook to reflect the untaken order
    broker.add_orderbook_mutation(lambda ob: (ob[0], [(22, 100)] + ob[1]))

    vb.generate_unsafe_orders(broker, broker, 'ABCXYZ', 100)
    print(broker.orders_placed)
    assert broker.orders_placed == [
        ('B', 'ABCXYZ', 22, 100, 0),
        ('S', 'ABCXYZ', 22, 100, 1),
    ]
    print(broker.orders_canceled)
    assert broker.orders_canceled == [0, 1]


def test_skewed_order_book(monkeypatch, vb, broker):
    broker._orderbook.bids.insert(0, (21, 1))
    broker._orderbook.bids.insert(0, (22, 1))
    broker._orderbook.bids.insert(0, (24, 1))
    broker._orderbook.bids.insert(0, (25, 1))
    broker._orderbook.bids.insert(0, (26, 1))
    broker._orderbook.bids.insert(0, (27, 1))

    vb.generate_unsafe_orders(broker, broker, 'ABCXYZ', 100)
    print(broker.orders_placed)
    assert broker.orders_placed == [
        ('S', 'ABCXYZ', 26, 100, 0),
        ('B', 'ABCXYZ', 26, 98, 1),
    ]
    assert broker.orders_canceled == [0, 1]
