import logging
from time import time

import pytest
from altonomy.apl_bots.ParticipationBot import ParticipationBot
from altonomy.apl_bots.TWAPBot import BotStatus
from altonomy.ref_data_api.api import InstrumentData

logger = logging.getLogger()


class FakeOrderMonitor:
    def __init__(self, alt_client=None, logger=None):
        self.dealt = 0
        self.dealt_price = 0
        self.open_orders = {}
        self.completed_orders = {}
        self.failed_orders = {}
        pass

    def cancel_all_open_orders(self):
        pass

    def start(self):
        pass

    def stop(self):
        pass


class FakeTWAPBot:
    def __init__(self, alt_client=None, logger=None):
        self.order_monitor = FakeOrderMonitor(alt_client, logger)
        self.min_order_qty = 1.0
        self.last_error = None
        self.start_time = time()
        self.reason = ""
        self.instrument_data = \
            FakeInstrumentDataSession().get_active_instrument("")
        self.balance = {}

    def instrument_data(self, **kwargs):
        return FakeInstrumentDataSession().get_active_instrument()

    def reset_twap_strategy(self):
        pass

    def cancel_pending_order(self):
        pass

    def calculate_strategy_params(self, qty, duration):
        pass

    def run(self):
        pass

    def validate_config_parameters(self):
        return not self.last_error


class FakeClient:
    class FakeZeroRPC:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_value, traceback,):
            pass

        def get_market_history(self, *args, **kwargs):
            kline_data = []
            ts = int(time())
            current_min = int(ts - (ts % 60))
            amount = 12.0
            for i in range(10):
                kline_data.append(
                    {
                        "amount": amount + i,
                        "time_open": (current_min - i * 60),
                        "time_close": (current_min - i * 60) + 59
                    })
            kline_data[0]['time_open'] = ts  # for tests to work
            return kline_data

    def __init__(self, pair):
        self.pair = pair
        self.zerorpc = FakeClient.FakeZeroRPC

    def client(self):
        return self

    def get_exchange_config(self, *args, **kwargs):
        return

    def get_account_config(self, exchange_id, account_id):
        return "test"

    def instrument_data(self, **kwargs):
        return FakeInstrumentDataSession()

    def register_resource_usage(self, type, exchange, pair):
        pass

    def deregister_resource_usage(self, type, exchange, pair):
        pass

    def exchange_name(self, name):
        return name

    def get(self, pos):
        return None


class FakeInstrumentDataSession:
    def get_active_instrument(self, exchange_id):
        ins_spot = InstrumentData()
        ins_spot.altonomy_symbol = 'ABC/XYZ-S'
        ins_spot.exchange_symbol = 'ABCXYZ'
        ins_spot.settlement_asset = 'XYZ'
        ins_spot.quote_coin = 'XYZ'
        ins_spot.min_order_notional = 10
        ins_spot.min_order_size = 1
        ins_spot.size_precision = 1
        ins_spot.tick_size = 1
        ins_spot.price_precision = 1
        return ins_spot


@pytest.fixture(autouse=True)
def set_log_cap_level(caplog):
    caplog.set_level(logging.DEBUG)


@pytest.fixture
def spot_client():
    return FakeClient('ABCXYZ')


@pytest.fixture
def twap_bot():
    return FakeTWAPBot()


class TestMethod:
    @pytest.fixture(scope="class")
    def monkeyclass(self):
        """Class scoped monkeypatch"""
        mpatch = pytest.MonkeyPatch()
        yield mpatch
        mpatch.undo


class TestBasicValidation(TestMethod):
    @pytest.fixture
    def participationbot(self, monkeypatch, spot_client, twap_bot):
        monkeypatch.setattr(
            ParticipationBot, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(
            ParticipationBot, 'name_of', lambda _, account_id: 'AAA')

        config = {
            "quantity": "1.0", "last_updated": "1642503271.523931",
            "duration": "300", "side": "BUY", "instrument_type": "SPOT"
        }

        with ParticipationBot(
            0, 'ABC', 'XYZ', -999, config, logger=logging.getLogger(),
            alt_client=spot_client,
            alt_twap_bot=twap_bot
        ) as participationbot:
            yield participationbot

    def test_config_format(
            self, participationbot, spot_client: FakeClient,
            twap_bot: FakeTWAPBot):

        twap_bot.last_error = "Total Qty(0.1) must be gt Min Order Qty(1)"
        twap_bot.bot_status = BotStatus.ERROR

        participationbot.run()
        assert participationbot.position['Status'] ==  \
            "Total Qty(0.1) must be gt Min Order Qty(1)"
        assert participationbot.bot_status == BotStatus.ERROR


class TestBotStatus(TestMethod):
    @pytest.fixture
    def participationbot(self, monkeypatch, spot_client, twap_bot):
        monkeypatch.setattr(
            ParticipationBot, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(
            ParticipationBot, 'name_of', lambda _, account_id: 'AAA')
        config = {
            "quantity": "200", "last_updated": "1642503271.523931",
            "duration": "100", "side": "BUY", "instrument_type": "SPOT"
        }

        with ParticipationBot(
            0, 'ABC', 'XYZ', -999, config, logger=logging.getLogger(),
            alt_client=spot_client,
            alt_twap_bot=twap_bot
        ) as participationbot:
            yield participationbot

    def test_pov_target_quantity(
            self, participationbot,
            spot_client: FakeClient, twap_bot: FakeTWAPBot):

        participationbot.order_size_rand_range = 0
        participationbot.run()

        assert not participationbot.last_error
        assert participationbot.bot_status == BotStatus.WAITING
        assert participationbot.target_quantity == 0.9

    def test_twap_error(
            self, participationbot,
            spot_client: FakeClient, twap_bot: FakeTWAPBot):

        twap_bot.bot_status = BotStatus.THRESHOLD_PRICE_BREACH
        twap_bot.start_time = time() + 1
        participationbot.run()
        assert not participationbot.last_error
        assert participationbot.bot_status == BotStatus.THRESHOLD_PRICE_BREACH

        twap_bot.bot_status = BotStatus.NOT_ENOUGH_BALANCE
        twap_bot.start_time = time() + 1
        participationbot.run()
        assert not participationbot.last_error
        assert participationbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE
