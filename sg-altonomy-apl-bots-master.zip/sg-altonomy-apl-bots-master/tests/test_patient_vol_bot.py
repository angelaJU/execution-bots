import logging
import random
from datetime import datetime
from types import SimpleNamespace
from typing import Callable, Iterable, List, NamedTuple, NewType, Tuple
from uuid import uuid4

import altonomy.apl_bots.VolumeBot as VolumeBot
import pytest
from altonomy.core.OrderBook import LegacyOrderBook, OrderBook
from altonomy.core.Order import Order

Price = NewType('Price', float)
Amount = NewType('Amount', float)
PriceLevel = NewType('PriceLevel', Tuple[Price, Amount])
Asks = NewType('Asks', Iterable[PriceLevel])
Bids = NewType('Bids', Iterable[PriceLevel])

logger = logging.getLogger()


class PlacedOrder(NamedTuple):
    side: str
    pair: str
    price: float
    amount: float
    order_id: int


class FakeBroker:
    class Orderbook(NamedTuple):
        asks: Iterable
        bids: Iterable

    def __init__(self, pair, initial_orderbook: Tuple[Asks, Bids]):
        self.pair = pair
        self._orderbook = FakeBroker.Orderbook(
            sorted(initial_orderbook[0]), sorted(initial_orderbook[1], reverse=True),
        )
        self.orderbook_mutations = [lambda x: x]
        self.orders_placed = []
        self.orders_canceled = []
        self.order_results = {}
        self.order_result_iterator = {}

        self.client = SimpleNamespace()
        self.client.buy_wait = self.buy
        self.client.sell_wait = self.sell
        self.client.get_order_details = self.client_order_details
        self.client.cancel_wait = self.cancel

        self.exchange = SimpleNamespace()

    def add_orderbook_mutation(
        self, mutation: Callable[[Tuple[Asks, Bids]], Tuple[Asks, Bids]]
    ):
        self.orderbook_mutations.append(mutation)

    def update_orderbook(self):
        try:
            mutation = self.orderbook_mutations.pop(0)
            self._orderbook = mutation(self._orderbook)
            logger.info('orderbook updated')
        except IndexError:
            pass

    @property
    def orderbook(self):
        ob = LegacyOrderBook(
            {
                self.pair: {
                    'asks': [
                        {'price': p, 'volume': v} for p, v in sorted(self._orderbook[0])
                    ],
                    'bids': [
                        {'price': p, 'volume': v}
                        for p, v in sorted(self._orderbook[1], reverse=True)
                    ],
                }
            }
        )
        logger.info(f'returned orderbook {ob}')
        return ob

    def buy(self, pair, price, amount):
        logger.info(f'placed buy order {pair} {price} {amount}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder('B', pair, price, amount, order_id))
        return [order_id, {'state': 'success',}]

    def sell(self, pair, price, amount):
        logger.info(f'placed sell order {pair} {price} {amount}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder('S', pair, price, amount, order_id))
        return [order_id, {'state': 'success',}]

    def cancel(self, order_id):
        logger.info(f'cancel order {order_id}')
        self.orders_canceled.append(order_id)

    def client_order_details(self, _, __, order_id):
        side, pair, price, amount, order_id = next(
            order for order in self.orders_placed if order[4] == order_id
        )

        try:
            order_results = next(
                self.order_result_iterator[order_id], self.order_results[order_id][-1]
            )
        except KeyError:
            self.order_result_iterator[order_id] = iter(self.order_results[order_id])
            order_results = next(self.order_result_iterator[order_id])

        od = {
            'order_ref': order_id,
            'pair': pair,
            'side': side,
            'price': price,
            'amount': amount,
            **order_results,
        }
        logger.info(f'retrieved order details {od}')
        return Order(od)


@pytest.fixture(autouse=True)
def set_log_cap_level(caplog):
    caplog.set_level(logging.DEBUG)


@pytest.fixture
def broker():
    return FakeBroker(
        'ABCXYZ',
        ([(i, 1000) for i in range(30, 40)], [(i, 1000) for i in range(10, 21)]),
    )


@pytest.fixture
def vb(monkeypatch, broker):
    monkeypatch.setattr(random, 'choice', lambda s: s[0])
    monkeypatch.setattr(random, 'uniform', max)
    monkeypatch.setattr(random, 'betavariate', lambda *args, **kwargs: 0)
    monkeypatch.setattr(random, 'triangular', lambda a, b, c: c)
    monkeypatch.setattr(VolumeBot.VolumeBot, '__init__', value=lambda *x: None)
    vb = VolumeBot.VolumeBot()
    vb._safe_size = None
    vb.minimumticksize = 1
    vb.minimum_order_size = 1
    vb.minimum_order_notional = 0
    vb.orderpricerounding = 0
    vb.explicit_wait_time = 0
    vb.orderpricerounding = 0
    vb.ordersizerounding = 0
    vb.orderwaitingtime = 0
    vb.internal_wait_time = 0
    vb.brokers = [broker]
    vb.tradingpair = 'ABCXYZ'
    vb.position = {}
    vb.probe_mode = False
    vb.logger = logging.getLogger()
    vb.log_order = lambda *args, **kwargs: None
    monkeypatch.setattr(vb, 'update_order_book_meaningfully', broker.update_orderbook)
    return vb


def test_basic_order_placement(monkeypatch, vb, broker):
    broker.order_results[0] = [
        {
            'state': ['FO'],
            'dealt': '100',
            'remaining_amount': '0',
            'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
        }
    ]
    vb.generate_patient_order(broker, broker, 'ABCXYZ', 100)
    # only one order placed
    logger.info(broker.orders_placed)
    assert len(broker.orders_placed) == 1
    assert broker.orders_placed == [('B', 'ABCXYZ', 21, 100, 0)]

    # order is completed, not cancelled
    assert broker.orders_canceled == []


def test_eat_own_order(monkeypatch, vb, broker):
    # order was not taken
    broker.order_results[0] = [
        {
            'state': ['AO'],
            'dealt': i,
            'remaining_amount': 10 - i,
            'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
        }
        for i in range(10 + 1)
    ]
    # change the orderbook to reflect the untaken order
    broker.add_orderbook_mutation(lambda ob: (ob[0], [(21, 10)] + ob[1]))
    for i in range(10 - 1, -1, -1):
        broker.add_orderbook_mutation(
            (lambda i: lambda ob: (ob[0], [(21, i)] + ob[1][1:]))(i)
        )

    # sell order also failed to clear, because e.g. this  exchange doesn't
    # allow self trades
    for i in range(1, 10):
        broker.order_results[i] = [
            {
                'state': ['AO'],
                'dealt': '1',
                'remaining_amount': '0',
                'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
            }
        ]
    vb.generate_patient_order(broker, broker, 'ABCXYZ', 10)
    logger.info(broker.orders_placed)
    # assert broker.orders_placed == [('B', 'ABCXYZ', 21, 10, 0)] + [
    #     ('S', 'ABCXYZ', 21, 1, i) for i in range(1, 11)
    # ]
    logger.info(broker.orders_canceled)
    # assert broker.orders_canceled == list(range(1, 11)) + [0]


def test_cancel_order_when_overbid(monkeypatch, vb, broker):
    # someone added a large order
    broker.add_orderbook_mutation(lambda ob: (ob[0], [(21, 1000)] + ob[1]))
    broker.order_results[0] = [
        {
            'state': ['AO'],
            'dealt': '0',
            'remaining_amount': '100',
            'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
        }
    ]
    vb.generate_patient_order(broker, broker, 'ABCXYZ', 100)
    logger.info(broker.orders_placed)
    assert len(broker.orders_placed) == 1
    order = broker.orders_placed[0]
    assert order == ('B', 'ABCXYZ', 21, 100, 0)
    assert len(broker.orders_canceled) == 1
    logger.info(broker.orders_canceled[0] == 0)


def test_skewed_order_book(monkeypatch, vb, broker):
    broker._orderbook.bids.insert(0, (21, 1))
    broker._orderbook.bids.insert(0, (22, 1))
    broker._orderbook.bids.insert(0, (24, 1))
    broker._orderbook.bids.insert(0, (25, 1))
    broker._orderbook.bids.insert(0, (26, 1))
    broker.order_results[0] = [
        {
            'state': ['FO'],
            'dealt': '100',
            'remaining_amount': '0',
            'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
        }
    ]
    vb.generate_patient_order(broker, broker, 'ABCXYZ', 100)
    logger.info(broker.orders_placed)
    assert broker.orders_placed == [('S', 'ABCXYZ', 29, 100, 0)]
