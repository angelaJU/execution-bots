import pytest
import pytest
import sys
import os
import inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir) 
import altonomy.apl_bots.config as config


class TestConfig(object):

    def test_config_exists(self):
        assert type(config.BROADCAST_CHANNEL) is str
        assert type(config.VOLUMEBOT_EMAIL_ALERT_TIME_PERIOD_MIN) is float
        assert type(config.RECORD_TO_CSV) is bool
        assert type(config.RECORD_TO_DB) is bool
        assert type(config.ACCOUNT_TS) is float
        assert type(config.RECORDING_TS) is float
