import logging
import random
import time
from datetime import datetime
from types import SimpleNamespace
from typing import Callable, Iterable, List, NamedTuple, NewType, Tuple
from uuid import uuid4

import altonomy.apl_bots.VolumeBot as VolumeBot
import pytest
from altonomy.core.Order import Order
from altonomy.core.OrderBook import LegacyOrderBook
from altonomy.exchanges import Order as ExchangeOrder

Price = NewType('Price', float)
Amount = NewType('Amount', float)
PriceLevel = NewType('PriceLevel', Tuple[Price, Amount])
Asks = NewType('Asks', Iterable[PriceLevel])
Bids = NewType('Bids', Iterable[PriceLevel])


class PlacedOrder(NamedTuple):
    side: str
    pair: str
    price: float
    amount: float
    order_id: int


class FakeBroker:
    class Orderbook(NamedTuple):
        asks: Iterable
        bids: Iterable

    def __init__(self, pair, initial_orderbook: Tuple[Asks, Bids]):
        self.pair = pair
        self._orderbook = FakeBroker.Orderbook(
            sorted(initial_orderbook[0]), sorted(initial_orderbook[1], reverse=True),
        )
        self.orderbook_mutations = [lambda x: x, lambda x: x]
        self.orders_placed = []
        self.orders_canceled = []
        self.order_results = {}

        self.client = SimpleNamespace()
        self.client.buy_wait = self.buy
        self.client.sell_wait = self.sell
        self.client.get_order_details = self.client_order_details
        self.client.cancel_wait = self.cancel

        self.exchange = SimpleNamespace()
        self.exchange.Order = ExchangeOrder.Order

    def add_orderbook_mutation(
        self, mutation: Callable[[Tuple[Asks, Bids]], Tuple[Asks, Bids]]
    ):
        self.orderbook_mutations.append(mutation)

    def update_orderbook(self):
        try:
            mutation = self.orderbook_mutations.pop(0)
            self._orderbook = mutation(self._orderbook)
        except IndexError:
            pass

    @property
    def orderbook(self):
        ob = LegacyOrderBook(
            {
                self.pair: {
                    'asks': [
                        {'price': p, 'volume': v} for p, v in sorted(self._orderbook[0])
                    ],
                    'bids': [
                        {'price': p, 'volume': v}
                        for p, v in sorted(self._orderbook[1], reverse=True)
                    ],
                }
            }
        )
        print(f'returned orderbook {ob}')
        return ob

    def buy(self, pair, price, amount):
        print(f'placed buy order {pair} {price} {amount}')
        order_id = len(self.orders_placed) + 1
        self.orders_placed.append(PlacedOrder('B', pair, price, amount, order_id))
        return [order_id, {'state': 'success',}]

    def sell(self, pair, price, amount):
        print(f'placed sell order {pair} {price} {amount}')
        order_id = len(self.orders_placed) + 1
        self.orders_placed.append(PlacedOrder('S', pair, price, amount, order_id))
        return [order_id, {'state': 'success',}]

    def cancel(self, order_id):
        print(f'cancel order {order_id}')
        self.orders_canceled.append(order_id)

    def client_order_details(self, _, __, order_id):
        side, pair, price, amount, order_id = next(
            order for order in self.orders_placed if order[4] == order_id
        )

        od = {
            'order_ref': order_id,
            'pair': pair,
            'side': side,
            'price': price,
            'amount': amount,
            **self.order_results[order_id],
        }
        print(f'retrieved order details {od}')
        return Order(od)


@pytest.fixture(autouse=True)
def set_log_cap_level(caplog):
    caplog.set_level(logging.DEBUG)


@pytest.fixture
def broker():
    return FakeBroker(
        'ABCXYZ',
        ([(i, 1000) for i in range(30, 40)], [(i, 1000) for i in range(10, 21)]),
    )


@pytest.fixture
def vb(monkeypatch, broker):
    monkeypatch.setattr(random, 'choice', lambda s: s[0])
    monkeypatch.setattr(random, 'triangular', lambda a, b, c: c)
    monkeypatch.setattr(random, 'uniform', lambda a, b: min(a, b))
    monkeypatch.setattr(VolumeBot.VolumeBot, '__init__', value=lambda *x: None)
    vb = VolumeBot.VolumeBot()
    vb.minimumticksize = 1
    vb.minimum_order_size = 1
    vb.minimum_order_notional = -1
    vb.orderpricerounding = 0
    vb.orderwaitingtime = 0
    vb.internal_wait_time = 0
    vb.position = {}
    vb.max_altcoin_imbalance = -1
    vb.max_quotecoin_imbalance = -1
    vb.logger = logging.getLogger()
    vb.brokers = [broker]
    vb.execution_mode = 'UNSAFE'
    vb._position_hold_time = 10800
    vb.position['completed'] = 999
    monkeypatch.setattr(vb, 'update_order_book_meaningfully', broker.update_orderbook)
    vb.tradingpair = 'ABCXYZ'
    vb._position_clearing_enabled = True
    return vb


def test_place_net_order_sell(monkeypatch, vb, broker):
    broker.order_results[1] = {
        'state': 'FO',
        'dealt': '1',
        'remaining_amount': '0',
        'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
    }
    broker._orderbook.bids.insert(0, (22, 100))
    vb.position['net'] = 1
    vb.position['fifo_price'] = 22
    vb.clear_net_position()
    # only one order placed
    print(broker.orders_placed)
    assert len(broker.orders_placed) == 1
    assert broker.orders_placed == [
        ('S', 'ABCXYZ', 22, 1, 1),
    ]

    # order is completely taken, not cancelled
    assert broker.orders_canceled == []


def test_place_net_order_buy(monkeypatch, vb, broker):
    broker.order_results[1] = {
        'state': 'FO',
        'dealt': '1',
        'remaining_amount': '0',
        'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
    }
    broker._orderbook.asks.insert(0, (22, 100))
    vb.position['net'] = -1
    vb.position['fifo_price'] = 22
    vb.clear_net_position()
    # only one order placed
    print(broker.orders_placed)
    assert len(broker.orders_placed) == 1
    assert broker.orders_placed == [
        ('B', 'ABCXYZ', 22, 1, 1),
    ]

    # order is completely taken, not cancelled
    assert broker.orders_canceled == []


def test_no_place_net_order(monkeypatch, vb, broker):
    broker._orderbook.asks.insert(0, (23, 100))
    vb.position['net'] = -1
    vb.position['fifo_price'] = 22
    vb.clear_net_position()
    # only one order placed
    print(broker.orders_placed)
    assert len(broker.orders_placed) == 0


def test_desperate_net_order(monkeypatch, vb, broker):
    broker.order_results[1] = {
        'state': 'FO',
        'dealt': '1',
        'remaining_amount': '0',
        'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
    }
    vb.last_position_improvement = time.time() - 60 * 60 * 3
    vb.max_altcoin_imbalance = 2
    broker._orderbook.asks.insert(0, (24, 100))
    vb.position['net'] = -1
    vb.position['fifo_price'] = 22
    vb.clear_net_position()
    # only one order placed
    print(broker.orders_placed)
    assert len(broker.orders_placed) == 1
    assert broker.orders_placed == [
        ('B', 'ABCXYZ', 24, 1, 1),
    ]

    # order is completely taken, not cancelled
    assert broker.orders_canceled == []


def test_no_desperate_net_order(monkeypatch, vb, broker):
    broker.order_results[1] = {
        'state': 'WF',
        'dealt': '1',
        'remaining_amount': '0',
        'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
    }
    vb.last_position_improvement = time.time() - 60 * 60 * 1.5
    vb.max_altcoin_imbalance = 2
    broker._orderbook.asks.insert(0, (24, 100))
    vb.position['net'] = -1
    vb.position['fifo_price'] = 22
    vb.clear_net_position()
    # only one order placed
    print(broker.orders_placed)
    assert len(broker.orders_placed) == 0


def test_position_improved(monkeypatch, vb, broker):
    vb.last_position_improvement = time.time() - 60 * 60 * 3
    vb.last_net_position = 2
    vb.max_altcoin_imbalance = 1
    broker._orderbook.asks.insert(0, (24, 100))
    vb.position['net'] = -1
    vb.position['fifo_price'] = 22
    vb.clear_net_position()
    # only one order placed
    print(broker.orders_placed)
    assert len(broker.orders_placed) == 0


def test_stuck_order(vb, broker, monkeypatch):
    monkeypatch.setattr(time, 'sleep', lambda *_: None)
    # order stuck in AO
    broker.order_results[1] = {
        'state': 'WF',
        'dealt': '0',
        'remaining_amount': '1',
        'update_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
    }
    broker._orderbook.asks.insert(0, (22, 100))
    vb.position['net'] = -1
    vb.position['fifo_price'] = 22
    vb.position['completed'] = 99
    vb._cleared_amount_total = 102
    vb.clear_net_position()

    print(broker.orders_placed)
    assert len(broker.orders_placed) == 1

    print(broker.orders_canceled)

    assert broker.orders_canceled == [1] * 8

    assert vb._position_clearing_enabled == False
