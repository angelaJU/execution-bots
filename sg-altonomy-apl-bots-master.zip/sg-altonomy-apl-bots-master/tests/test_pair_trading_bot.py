from altonomy.core.AccountBalance import AccountBalance
from altonomy.apl_bots.OrderMonitor import OrderMonitor
import logging
import math
import random
from datetime import datetime
import time
from traceback import clear_frames
from types import SimpleNamespace
from typing import Callable, Iterable, List, NamedTuple, NewType, Tuple
from uuid import uuid4

import pytest
import altonomy.core as core
from altonomy.core.Order import Order
from altonomy.core.OrderBook import LegacyOrderBook
from altonomy.core.Side import BUY, SELL, Side
from altonomy.apl_bots.PairTradingBot import *
from altonomy.ref_data_api.api import InstrumentData

Price = NewType('Price', float)
Amount = NewType('Amount', float)
PriceLevel = NewType('PriceLevel', Tuple[Price, Amount])
Asks = NewType('Asks', Iterable[PriceLevel])
Bids = NewType('Bids', Iterable[PriceLevel])

logger = logging.getLogger()


class PlacedOrder(NamedTuple):
    side: str
    pair: str
    price: float
    amount: float
    order_id: int


class FakeClient:
    def __init__(self, pair):
        self.pair = pair
        self._orderbooks = []
        self.orderbook_index = 0
        self.orders_placed = []
        self.orders_canceled = []
        self.order_results = {}
        self.order_result_iterator = {}
        self.account_balance = {}
        self.get_orderbook = self.orderbook

    def orderbook(self, *args, **kwargs):
        if self.orderbook_index <  len(self._orderbooks):
            bb_size, bb_price, ba_price, ba_size = self._orderbooks[self.orderbook_index]
                    
            ob = LegacyOrderBook(
                {
                    self.pair: {
                        'asks': [
                            {'price': ba_price, 'volume': ba_size}
                        ],
                        'bids': [
                            {'price': bb_price, 'volume': bb_size}
                        ],
                    }
                }
            )
        else:
            ob = LegacyOrderBook(
                {
                    self.pair: {
                        'asks': [],
                        'bids': [],
                    }
                }
            )
        self.orderbook_index += 1
        ob.timestamp = time.time()
        logger.info(f'returned orderbook {ob}')
        return ob

    # def add_price_level(self, side: Side, price, amount):
    #     if side == BUY:
    #         self._orderbooks[self.orderbook_index].bids.append((price, amount))
    #         self.orderbook_index += 1
    #     elif side == SELL:
    #         self._orderbooks[self.orderbook_index].asks.append((price, amount))
    #         self.orderbook_index += 1
    #     else:
    #         raise ValueError

    def add_books(self, bbos: list = [[0,0,0,0]]):
        for bbo in bbos:
            self._orderbooks.insert(len(self._orderbooks), bbo)

    def buy(self, pair, price, size, order_type, account_id=None, remark=None):
        logger.info(f'placed buy order {pair} {price} {size}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder('BUY', pair, price, size, order_id))
        return order_id

    def sell(self, pair, price, size, order_type, account_id=None, remark=None):
        logger.info(f'placed sell order {pair} {price} {size}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder('SELL', pair, price, size, order_id))
        return order_id

    def cancel(self, order_id):
        logger.info(f'cancel order {order_id}')
        self.orders_canceled.append(order_id)

    def get_order_details(self, *, order_id, **kwargs):
        side, pair, price, amount, order_id = next(
            order for order in self.orders_placed if order[4] == order_id
        )

        try:
            order_results = next(
                self.order_result_iterator[order_id], self.order_results[order_id][-1]
            )
        except KeyError:
            self.order_result_iterator[order_id] = iter(self.order_results[order_id])
            order_results = next(self.order_result_iterator[order_id])

        od = {
            'order_ref': order_id,
            'pair': pair,
            'side': side,
            'price': price,
            'size': amount,
            **order_results,
        }
        logger.info(f'retrieved order details {od}')
        return Order(od)

    def client(self):
        return self

    def get_exchange_config(self, *args, **kwargs):
        return

    def get_account_config(self, config, account_id):
        configs = {
            0 : {'is_futures' : 'False', 'dual_side_position' : 'False', 'exchange_name' : 'Binance'},
            1 : {'is_futures' : 'True', 'dual_side_position' : 'False', 'exchange_name' : 'Binancedm'},
            2 : {'is_futures' : 'True', 'dual_side_position' : 'True', 'exchange_name' : 'Binancedmx'},
            3 : {'is_futures' : 'False', 'dual_side_position' : 'False', 'exchange_name' : 'Binance'},
            4 : {'is_futures' : 'False', 'dual_side_position' : 'False', 'exchange_name' : 'Huobi'},
            5 : {'is_futures' : 'False', 'dual_side_position' : 'False', 'exchange_name' : 'Coinbase'},
            6 : {'is_futures' : 'False', 'dual_side_position' : 'False', 'exchange_name' : 'Kraken'},
            7 : {'is_futures' : 'False', 'dual_side_position' : 'False', 'exchange_name' : 'Okex'},
            8 : {'is_futures' : 'False', 'dual_side_position' : 'False', 'exchange_name' : 'Kucoin'},
            '' : {'is_futures' : 'False', 'dual_side_position' : 'False', 'exchange_name' : 'None'}
        }
        return configs[account_id][config]

    def get_account_balance(self, account_id, **kwargs):
        inf_balance = AccountBalance()
        inf_balance['ABC'].available = math.inf
        inf_balance['PQR'].available = math.inf
        inf_balance['XYZ'].available = math.inf
        inf_balance['BTC'].available = math.inf
        inf_balance['USDT'].available = math.inf
        inf_balance['ABCUSDT Long'].available = math.inf
        inf_balance['ABCUSDT Short'].available = math.inf
        inf_balance['ABCUSD_PERP Long'].available = math.inf
        inf_balance['ABCUSDT_PERP Short'].available = math.inf
        return self.account_balance.get(account_id, inf_balance)

    def get_product_leverage(self, pair, account_id, **kwargs):
        return 10

    def instrument_data(self, **kwargs):
        return FakeInstrumentDataSession()

    def register_resource_usage(self, type, exchange, pair):
        pass

    def deregister_resource_usage(self, type, exchange, pair):
        pass

    def exchange_name(self, name):
        return name

class FakeInstrumentDataSession:
    def get_active_instruments_for_exchange(self, exchange_id):
        ins_spot = InstrumentData()
        ins_spot.altonomy_symbol = 'ABC/XYZ-S'
        ins_spot.exchange_symbol = 'ABCXYZ'
        ins_spot.settlement_asset = 'XYZ'
        ins_spot.quote_coin = 'XYZ'
        ins_spot.min_order_notional = 10
        ins_spot.min_order_size = 1
        ins_spot.size_precision = 1
        ins_spot.tick_size = 1

        ins_spot2 = InstrumentData()
        ins_spot2.altonomy_symbol = 'PQR/XYZ-S'
        ins_spot2.exchange_symbol = 'PQRXYZ'
        ins_spot2.settlement_asset = 'XYZ'
        ins_spot2.quote_coin = 'XYZ'
        ins_spot2.min_order_notional = 10
        ins_spot2.min_order_size = 1
        ins_spot2.size_precision = 1
        ins_spot2.tick_size = 1

        ins_spot3 = InstrumentData()
        ins_spot3.altonomy_symbol = 'ABC/USD-S'
        ins_spot3.exchange_symbol = 'ABCUSD'
        ins_spot3.settlement_asset = 'USD'
        ins_spot3.quote_coin = 'USD'
        ins_spot3.min_order_notional = 10
        ins_spot3.min_order_size = 1
        ins_spot3.size_precision = 1
        ins_spot3.tick_size = 1


        ins_usd_fut = InstrumentData()
        ins_usd_fut.altonomy_symbol = 'ABC/USDT-P/USDT'
        ins_usd_fut.exchange_symbol = 'ABCUSDT'
        ins_usd_fut.settlement_asset = 'USDT'
        ins_usd_fut.quote_coin = 'USDT'
        ins_usd_fut.min_order_notional = 10
        ins_usd_fut.min_order_size = 1
        ins_usd_fut.size_precision = 1
        ins_usd_fut.tick_size = 1

        ins_usd_fut2 = InstrumentData()
        ins_usd_fut2.altonomy_symbol = 'LMN/BUSD-P/BUSD'
        ins_usd_fut2.exchange_symbol = 'LMNBUSD'
        ins_usd_fut2.settlement_asset = 'BUSD'
        ins_usd_fut2.quote_coin = 'BUSD'
        ins_usd_fut2.min_order_notional = 10
        ins_usd_fut2.min_order_size = 1
        ins_usd_fut2.size_precision = 1
        ins_usd_fut2.tick_size = 1

        ins_coin_fut = InstrumentData()
        ins_coin_fut.altonomy_symbol = 'ABC/USD-P/COIN'
        ins_coin_fut.exchange_symbol = 'ABCUSD_PERP'
        ins_coin_fut.settlement_asset = 'ABC'
        ins_coin_fut.quote_coin = 'USD'
        ins_coin_fut.contract_size = 10
        ins_coin_fut.min_order_notional = 10
        ins_coin_fut.min_order_size = 1
        ins_coin_fut.size_precision = 1
        ins_coin_fut.tick_size = 1

        huobi = InstrumentData()
        huobi.altonomy_symbol = 'BTC/USDT-S'
        huobi.exchange_symbol = 'btcusdt'
        huobi.settlement_asset = 'USDT'
        huobi.quote_coin = 'USDT'
        huobi.min_order_notional = 10
        huobi.min_order_size = 1
        huobi.size_precision = 1
        huobi.tick_size = 1

        coinbase = InstrumentData()
        coinbase.altonomy_symbol = 'BTC/USDT-S'
        coinbase.exchange_symbol = 'BTC-USDT'
        coinbase.settlement_asset = 'USDT'
        coinbase.quote_coin = 'USDT'
        coinbase.min_order_notional = 10
        coinbase.min_order_size = 1
        coinbase.size_precision = 1
        coinbase.tick_size = 1

        kraken = InstrumentData()
        kraken.altonomy_symbol = 'BTC/USDT-S'
        kraken.exchange_symbol = 'XBTUSDT'
        kraken.settlement_asset = 'USDT'
        kraken.quote_coin = 'USDT'
        kraken.min_order_notional = None
        kraken.min_order_size = 1
        kraken.size_precision = 1
        kraken.tick_size = 1

        okex = InstrumentData()
        okex.altonomy_symbol = 'BTC/USDT-S'
        okex.exchange_symbol = 'BTC-USDT'
        okex.settlement_asset = 'USDT'
        okex.quote_coin = 'USDT'
        okex.min_order_notional = None
        okex.min_order_size = 1
        okex.size_precision = 1
        okex.tick_size = 1

        kucoin = InstrumentData()
        kucoin.altonomy_symbol = 'BTC/USDT-S'
        kucoin.exchange_symbol = 'BTC-USDT'
        kucoin.settlement_asset = 'USDT'
        kucoin.quote_coin = 'USDT'
        kucoin.min_order_notional = None
        kucoin.min_order_size = 1
        kucoin.size_precision = 1
        kucoin.tick_size = 1


        
        return [ins_spot, ins_spot2, ins_spot3, ins_usd_fut, ins_usd_fut2, ins_coin_fut, huobi, coinbase, kraken, okex, kucoin]

class FakePricer:
    def get_rate(self, coin1, coin2):
        rates = {
            'ABC' : {
                'USDT' : 10.0
            },
            'USDC' : {
                'USDT' : 1.0
            },
            'USD' : {
                'USDT' : 1.0
            },
            'PQR' : {
                'USDT' : 20.0
            }
        }

        return rates[coin1][coin2]
        



@pytest.fixture(autouse=True)
def set_log_cap_level(caplog):
    caplog.set_level(logging.DEBUG)


@pytest.fixture
def spot_client():
    return FakeClient('ABCXYZ')

@pytest.fixture
def spot_client_2():
    return FakeClient('PQRXYZ')

@pytest.fixture
def usdm_client():
    return FakeClient('ABCUSDT')

@pytest.fixture
def coinm_client():
    return FakeClient('ABCUSD_PERP')

@pytest.fixture
def pricer():
    return FakePricer()


class TestMethod:
    @pytest.fixture(scope="class")
    def monkeyclass(self):
        """Class scoped monkeypatch"""
        mpatch = MonkeyPatch()
        yield mpatch
        mpatch.undo



class TestBasicValidation(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')        
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_config_format(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.position['Status'] == ERR_INVALID_CONFIG_PARAMETERS

    def test_validate_base(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == ERR_INVALID_CONFIG_PARAMETERS
        assert ptb.legs['primary'].leg_status == LegStatus.WAITING
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.ERROR
        assert ptb.legs['pair'].last_error == ERR_LEG_BASE_AND_QUOTE_EMPTY

    def test_validate_quote(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == ERR_INVALID_CONFIG_PARAMETERS
        assert ptb.legs['primary'].leg_status == LegStatus.WAITING
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.ERROR
        assert ptb.legs['pair'].last_error == ERR_LEG_BASE_AND_QUOTE_EMPTY

    def test_validate_account(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": '', "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == ERR_INVALID_CONFIG_PARAMETERS
        assert ptb.legs['primary'].leg_status == LegStatus.WAITING
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.ERROR
        assert ptb.legs['pair'].last_error == ERR_LEG_ACCOUNT_ID_EMPTY

    def test_validate_instrument_data(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABCD", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == ERR_INVALID_CONFIG_PARAMETERS
        assert ptb.legs['primary'].leg_status == LegStatus.WAITING
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.ERROR
        assert ptb.legs['pair'].last_error == ERR_LEG_INSTRUMENT_DATA_UNAVAILABLE

    def test_validate_qty(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 0.1, "slice_size": 0.1, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == ERR_INVALID_CONFIG_PARAMETERS
        assert ptb.legs['primary'].leg_status == LegStatus.ERROR
        assert ptb.legs['primary'].last_error == ERR_LEG_QTY_LESS_THAN_MIN_QTY.format(0.1, 1)
        assert ptb.legs['pair'].leg_status == LegStatus.ERROR
        assert ptb.legs['pair'].last_error == ERR_LEG_QTY_LESS_THAN_MIN_QTY.format(0.1, 1)

    def test_validate_slice_size(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 10, "slice_size": 0.1, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == ERR_INVALID_CONFIG_PARAMETERS
        assert ptb.legs['primary'].leg_status == LegStatus.ERROR
        assert ptb.legs['primary'].last_error == ERR_LEG_SLICE_SIZE_LESS_THAN_MIN_QTY.format(0.1, 1)
        assert ptb.legs['pair'].leg_status == LegStatus.ERROR
        assert ptb.legs['pair'].last_error == ERR_LEG_SLICE_SIZE_LESS_THAN_MIN_QTY.format(0.1, 1)
        
    def test_validate_conversion_rate(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "LMN", "quote": "BUSD", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)

        assert ptb.last_error == ERR_INVALID_CONFIG_PARAMETERS
        assert ptb.legs['primary'].leg_status == LegStatus.WAITING
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.ERROR
        assert ptb.legs['pair'].last_error == ERR_LEG_BASE_USDT_CONVERSION_UNAVAILABLE.format("LMN")

class TestLegStatus(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_auto_side(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == None
        assert ptb.legs['primary'].leg_status == LegStatus.ERROR
        assert ptb.legs['primary'].last_error == ERR_LEG_UNABLE_TO_SET_AUTO_SIDE
        assert ptb.legs['pair'].leg_status == LegStatus.WAITING
        assert ptb.legs['pair'].last_error == None

    def test_order_status(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 10, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == None
        assert ptb.legs['primary'].leg_status == LegStatus.ORDER_SUBMITTED
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.WAITING
        assert ptb.legs['pair'].reason == f'{TradableBitMask.DependencyNotSatisfied.name}'


        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'CO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert ptb.last_error == None
        assert ptb.legs['primary'].leg_status == LegStatus.ORDER_CANCELLED
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.WAITING
        assert ptb.legs['pair'].reason == f'{TradableBitMask.DependencyNotSatisfied.name}'

        spot_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert ptb.last_error == None
        assert ptb.legs['primary'].leg_status == LegStatus.ORDER_SUBMITTED
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.WAITING
        assert ptb.legs['pair'].reason == f'{TradableBitMask.DependencyNotSatisfied.name}'

        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert ptb.last_error == None
        assert ptb.legs['primary'].leg_status == LegStatus.LEG_COMPLETED
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.ORDER_SUBMITTED
        assert ptb.legs['pair'].reason == ''

    def test_balance(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['XYZ'].available = 12 * 9
        spot_client.account_balance[0] = low_balance
        
        ptb.run()
        time.sleep(1)
        assert ptb.last_error == None
        assert ptb.legs['primary'].leg_status == LegStatus.NOT_ENOUGH_BALANCE
        assert ptb.legs['primary'].last_error == None
        assert ptb.legs['pair'].leg_status == LegStatus.WAITING
        assert ptb.legs['pair'].reason == f'{TradableBitMask.DependencyNotSatisfied.name}'

class TestBasicOrderFlow(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')

        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_single_trade(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]
        
        
    def test_requote_no_fill(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []

        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'CO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []

        spot_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0), (BUY, 'ABCXYZ', 13, 10, 1)]
        assert usdm_client.orders_placed == []

        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0), (BUY, 'ABCXYZ', 13, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]

    def test_requote_partially_fill(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]

            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]

            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'PF', 'dealt': '5', 'remaining_amount': '5', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []

        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '5', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'CO', 'dealt': '5', 'remaining_amount': '5', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '5', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 5, 0)]

        spot_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0), (BUY, 'ABCXYZ', 13, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 5, 0)]

        usdm_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0), (BUY, 'ABCXYZ', 13, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 5, 0), (SELL, 'ABCUSDT', 9, 10, 1)]
        
        spot_client.order_results[2] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '5', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[2] = [{ 'state': 'FO', 'dealt': '5', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0), (BUY, 'ABCXYZ', 13, 10, 1), (BUY, 'ABCXYZ', 13, 5, 2)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 5, 0), (SELL, 'ABCUSDT', 9, 10, 1)]

        usdm_client.order_results[2] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '5', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[2] = [{ 'state': 'FO', 'dealt': '5', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0), (BUY, 'ABCXYZ', 13, 10, 1), (BUY, 'ABCXYZ', 13, 5, 2)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 5, 0), (SELL, 'ABCUSDT', 9, 10, 1), (SELL, 'ABCUSDT', 9, 5, 2)]
        
    def test_failed_order(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]

            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]

            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'OR', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []

        
        spot_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0), (BUY, 'ABCXYZ', 13, 10, 1)]
        assert usdm_client.orders_placed == []

        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0), (BUY, 'ABCXYZ', 13, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]

class TestDependencyCheck(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_spread_bigger_check(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.5, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                
            ]
        )
        usdm_client.add_books(
            [
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   9,  11, 100],
                [100,   9,  11, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   9,  11, 100],
                [100,   9,  11, 100],
                
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 11, 10, 0)]

        spot_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0),(BUY, 'ABCXYZ', 10, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 11, 10, 0)]
        
        
        usdm_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0),(BUY, 'ABCXYZ', 10, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 11, 10, 0),(SELL, 'ABCUSDT', 11, 10, 1)]

    def test_spread_smaller_check(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_SMALLER_THAN", "start_threshold": 2, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   11, 12, 100],
                [100,   11, 12, 100],
                [100,   10, 12, 100],
                [100,   11, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                
            ]
        )
        usdm_client.add_books(
            [
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                
            ]
        )
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == []
        assert usdm_client.orders_placed == []
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]
    
    def test_spread_bigger_with_direction_check(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN_WITH_DIRECTION", "start_threshold": 0.5, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                
            ]
        )
        usdm_client.add_books(
            [
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   9,  11, 100],
                [100,   9,  11, 100],
                [100,   9,  11, 100],
                [100,   9,  11, 100],
                
            ]
        )
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == []
        assert usdm_client.orders_placed == []
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 11, 10, 0)]

    def test_spread_smaller_with_direction_check(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_SMALLER_THAN_WITH_DIRECTION", "start_threshold": 2, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   11, 12, 100],
                [100,   11, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                
            ]
        )
        usdm_client.add_books(
            [
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   8, 9, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                
            ]
        )
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == []
        assert usdm_client.orders_placed == []
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]

        spot_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0),(BUY, 'ABCXYZ', 10, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]
        
        usdm_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 10, 10, 0),(BUY, 'ABCXYZ', 10, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0), (SELL, 'ABCUSDT', 12, 10, 1)]

class TestBalanceCheck(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_spot_buy(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['XYZ'].available = 12 * 9
        spot_client.account_balance[0] = low_balance
        
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == []
        assert usdm_client.orders_placed == []

        enough_balance = AccountBalance()
        enough_balance['XYZ'].available = 12 * 10
        spot_client.account_balance[0] = enough_balance
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
    def test_spot_sell(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['ABC'].available = 9
        spot_client.account_balance[0] = low_balance
        
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == []
        assert usdm_client.orders_placed == []

        enough_balance = AccountBalance()
        enough_balance['ABC'].available = 10
        spot_client.account_balance[0] = enough_balance
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
        
    def test_usdm_sell_position_balance(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        low_balance = AccountBalance()
        low_balance['ABCUSDT Long'].available = 9
        usdm_client.account_balance[1] = low_balance

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        enough_balance = AccountBalance()
        enough_balance['ABCUSDT Long'].available = 10
        usdm_client.account_balance[1] = enough_balance
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]

    def test_usdm_sell_margin_balance(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        low_balance = AccountBalance()
        low_balance['USDT'].available = 9
        usdm_client.account_balance[1] = low_balance

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        enough_balance = AccountBalance()
        enough_balance['USDT'].available = 10
        usdm_client.account_balance[1] = enough_balance
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]

    def test_usdm_buy_position_balance(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        low_balance = AccountBalance()
        low_balance['ABCUSDT Short'].available = 9
        usdm_client.account_balance[1] = low_balance

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        enough_balance = AccountBalance()
        enough_balance['ABCUSDT Short'].available = 10
        usdm_client.account_balance[1] = enough_balance
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == [(BUY, 'ABCUSDT', 9, 10, 0)]

    def test_usdm_buy_margin_balance(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        low_balance = AccountBalance()
        low_balance['USDT'].available = 9
        usdm_client.account_balance[1] = low_balance

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        enough_balance = AccountBalance()
        enough_balance['USDT'].available = 10
        usdm_client.account_balance[1] = enough_balance
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == [(BUY, 'ABCUSDT', 9, 10, 0)]

class TestBalanceCheckCoinM(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, coinm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        coinm_client.add_books(
            [[100, 9, 11, 100]]
        )
        
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=coinm_client, pricer=pricer, 
        ) as ptb:
            yield ptb

    def test_coinm_sell_open(self, ptb, spot_client: FakeClient, coinm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 2, "base": "ABC", "quote": "USD_PERP", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        coinm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == []
        
        low_balance = AccountBalance()
        low_balance['ABC'].available = 0.9
        coinm_client.account_balance[2] = low_balance

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == []
        
        enough_balance = AccountBalance()
        enough_balance['ABC'].available = 1
        coinm_client.account_balance[2] = enough_balance
        
        coinm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        coinm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == [(SELL, 'ABCUSD_PERP', 10, 10, 0)]

    def test_coinm_sell_close(self, ptb, spot_client: FakeClient, coinm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 2, "base": "ABC", "quote": "USD_PERP", "side": "SELL", "order_type": "LIMIT_CLOSE", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        coinm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == []
        
        low_balance = AccountBalance()
        low_balance['ABCUSD_PERP Long'].available = 9
        coinm_client.account_balance[2] = low_balance

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == []
        
        enough_balance = AccountBalance()
        enough_balance['ABCUSD_PERP Long'].available = 10
        coinm_client.account_balance[2] = enough_balance
        
        coinm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        coinm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == [(SELL, 'ABCUSD_PERP', 10, 10, 0)]

    def test_coinm_buy_open(self, ptb, spot_client: FakeClient, coinm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 2, "base": "ABC", "quote": "USD_PERP", "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        coinm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == []
        
        low_balance = AccountBalance()
        low_balance['ABC'].available = 0.9
        coinm_client.account_balance[2] = low_balance

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == []
        
        enough_balance = AccountBalance()
        enough_balance['ABC'].available = 1
        coinm_client.account_balance[2] = enough_balance
        
        coinm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        coinm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == [(BUY, 'ABCUSD_PERP', 10, 10, 0)]

    def test_coinm_buy_close(self, ptb, spot_client: FakeClient, coinm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 2, "base": "ABC", "quote": "USD_PERP", "side": "BUY", "order_type": "LIMIT_CLOSE", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        coinm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == []
        
        low_balance = AccountBalance()
        low_balance['ABCUSD_PERP Short'].available = 9
        coinm_client.account_balance[2] = low_balance

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == []
        
        enough_balance = AccountBalance()
        enough_balance['ABCUSD_PERP Short'].available = 10
        coinm_client.account_balance[2] = enough_balance
        
        coinm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        coinm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 12, 10, 0)]
        assert coinm_client.orders_placed == [(BUY, 'ABCUSD_PERP', 10, 10, 0)]

class TestSpotSpot(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, spot_client_2, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        spot_client_2.add_books(
            [[100, 20, 21, 100],
            [100, 19, 21, 100]]
        )
        
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=spot_client_2, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_notional_check(self, ptb, spot_client: FakeClient, spot_client_2):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 3, "base": "PQR", "quote": "XYZ", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]

            ]
        )
        spot_client_2.add_books(
            [
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert spot_client_2.orders_placed == []
        
        spot_client_2.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '5', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client_2.order_results[0] = [{ 'state': 'FO', 'dealt': '5', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert spot_client_2.orders_placed == [(SELL, 'PQRXYZ', 20, 5, 0)]
    
    def test_min_order_check(self, ptb, spot_client: FakeClient, spot_client_2):
        ptb.config = {
            "quantity": 2, "slice_size": 1, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 3, "base": "PQR", "quote": "XYZ", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client_2.add_books(
            [
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100]
            ]
        )
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == []
        assert spot_client_2.orders_placed == []

class TestSpotUSDM(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client_2, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        spot_client_2.add_books(
            [[100, 20, 21, 100],
            [100, 19, 21, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [3], 'PQR', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client_2, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_notional_check(self, ptb, spot_client_2: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 2, "slice_size": 1, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client_2.add_books(
            [
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client_2.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '1', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client_2.order_results[0] = [{ 'state': 'FO', 'dealt': '1', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client_2.orders_placed == [(BUY, 'PQRXYZ', 21, 1, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '2', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '2', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client_2.orders_placed == [(BUY, 'PQRXYZ', 21, 1, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 2, 0)]
    
    def test_min_order_check(self, ptb, spot_client_2: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 2, "slice_size": 0.5, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client_2.add_books(
            [
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100]
            ]
        )
        ptb.run()
        time.sleep(1)
        assert usdm_client.orders_placed == []
        assert spot_client_2.orders_placed == []

class TestSpotCOINM(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client_2, coinm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        spot_client_2.add_books(
            [[100, 20, 21, 100],
            [100, 20, 21, 100]]
        )
        coinm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [3], 'PQR', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client_2, pair_client=coinm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_notional_check(self, ptb, spot_client_2: FakeClient, coinm_client):
        ptb.config = {
            "quantity": 2, "slice_size": 1, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 2, "base": "ABC", "quote": "USD_PERP", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client_2.add_books(
            [
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100]
            ]
        )
        coinm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client_2.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '1', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client_2.order_results[0] = [{ 'state': 'FO', 'dealt': '1', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client_2.orders_placed == [(BUY, 'PQRXYZ', 21, 1, 0)]
        assert coinm_client.orders_placed == []
        
        coinm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '2', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        coinm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '2', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client_2.orders_placed == [(BUY, 'PQRXYZ', 21, 1, 0)]
        assert coinm_client.orders_placed == [(SELL, 'ABCUSD_PERP', 9, 2, 0)]
    
    def test_min_order_check(self, ptb, spot_client_2: FakeClient, coinm_client):
        ptb.config = {
            "quantity": 2, "slice_size": 0.5, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 2, "base": "ABC", "quote": "USD_PERP", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        coinm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client_2.add_books(
            [
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100],
                [100,   20, 21, 100]
            ]
        )
        ptb.run()
        time.sleep(1)
        assert coinm_client.orders_placed == []
        assert spot_client_2.orders_placed == []

class TestEditBot(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_quantity_and_aggresiveness_change(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 13, 10, 0)]

        spot_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0), (BUY, 'ABCXYZ', 9, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 13, 10, 0)]
        
        usdm_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0), (BUY, 'ABCXYZ', 9, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 13, 10, 0), (SELL, 'ABCUSDT', 13, 10, 1)]

        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0), (BUY, 'ABCXYZ', 9, 10, 1)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 13, 10, 0), (SELL, 'ABCUSDT', 13, 10, 1)]

        ptb.config = {
            "quantity": 25, "slice_size": 5, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.order_results[2] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '5', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[2] = [{ 'state': 'FO', 'dealt': '5', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0), (BUY, 'ABCXYZ', 9, 10, 1), (BUY, 'ABCXYZ', 13, 5, 2)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 13, 10, 0), (SELL, 'ABCUSDT', 13, 10, 1)]
        
        usdm_client.order_results[2] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '5', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[2] = [{ 'state': 'FO', 'dealt': '5', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0), (BUY, 'ABCXYZ', 9, 10, 1), (BUY, 'ABCXYZ', 13, 5, 2)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 13, 10, 0), (SELL, 'ABCUSDT', 13, 10, 1), (SELL, 'ABCUSDT', 9, 5, 2)]

    def test_spread_start_change(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 4, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == []
        assert usdm_client.orders_placed == []
        
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 3, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }

        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0)]
        assert usdm_client.orders_placed == []

        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 13, 10, 0)]
        
    def test_spread_suspend_change(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "SPREAD_SMALLER_THAN","suspend_threshold": 5}
        }
        spot_client.add_books(
            [
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == []
        assert usdm_client.orders_placed == []
        
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "ON_TOP",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "ON_TOP"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0, "suspend_if": "SPREAD_SMALLER_THAN","suspend_threshold": 4}
        }

        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0)]
        assert usdm_client.orders_placed == []

        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 9, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 13, 10, 0)]

class TestAutoSideMode(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_equal_mid(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0.0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 10, 0)]
       
    def test_mid_lesser(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0.0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
            ]
        )
        usdm_client.add_books(
            [
                [100,   11, 13, 100],
                [100,   11, 13, 100],
                [100,   11, 13, 100],
                [100,   11, 13, 100],
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'ABCXYZ', 12, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 11, 10, 0)]

    def test_mid_greater(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0.0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
            ]
        )
        usdm_client.add_books(
            [
                [100,   9, 11, 100],
                [100,   9, 11, 100],
                [100,   9, 11, 100],
                [100,   9, 11, 100],
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == [(BUY, 'ABCUSDT', 11, 10, 0)]
       
    def test_notional_check_1_sell_2_sell_buy(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0.0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9, 11, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                
            ]
        )
        usdm_client.add_books(
            [
                [100,   9, 11, 100],
                [100,   9, 11, 100],
                [100,   9, 11, 100],
                [100,   10, 12, 100],
                [100,   9, 11, 100],
                [100,   9, 11, 100],
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
        
        ptb.run()
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
       
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == [(BUY, 'ABCUSDT', 11, 10, 0)]

    def test_notional_check_1_sell_buy_2_sell_buy(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "AUTO", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "NO_CONDITION", "start_threshold": 0.0, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9, 11, 100],
                [100,   9, 11, 100],
                [100,   10, 12, 100],
                [100,   9, 11, 100],
            ]
        )
        usdm_client.add_books(
            [
                [100,   9, 11, 100],
                [100,   9, 11, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9, 11, 100],
                [100,   10, 12, 100],

            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0)]
        assert usdm_client.orders_placed == []
        
        spot_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0), (BUY, 'ABCXYZ', 11, 10, 1)]
        assert usdm_client.orders_placed == []
       
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0), (BUY, 'ABCXYZ', 11, 10, 1)]
        assert usdm_client.orders_placed == [(BUY, 'ABCUSDT', 11, 10, 0)]
       
        usdm_client.order_results[1] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[1] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(SELL, 'ABCXYZ', 10, 10, 0), (BUY, 'ABCXYZ', 11, 10, 1)]
        assert usdm_client.orders_placed == [(BUY, 'ABCUSDT', 11, 10, 0), (SELL, 'ABCUSDT', 10, 10, 1)]

class TestConvertionRate(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')
        
        
        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100],
            [100, 9, 11, 100]]
        )
        with PairTradingBot(
            [0], 'ABC', 'XYZ', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_quote_usdt(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.legs['pair'].base_usdt_convertion_rate == 10
        assert ptb.legs['pair'].usd_usdt_convertion_rate == 1

    def test_quote_usd(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 0, "base": "ABC", "quote": "USD", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.legs['pair'].base_usdt_convertion_rate == 10
        assert ptb.legs['pair'].usd_usdt_convertion_rate == 1

    def test_quote_other(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 0, "base": "ABC", "quote": "XYZ", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.legs['pair'].base_usdt_convertion_rate == 10
        assert ptb.legs['pair'].usd_usdt_convertion_rate == 1

    def test_quote_coin_margin(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 0, "base": "ABC", "quote": "USD_PERP", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        
        ptb.run()
        time.sleep(1)
        assert ptb.legs['pair'].base_usdt_convertion_rate == 10
        assert ptb.legs['pair'].usd_usdt_convertion_rate == 1

class TestKucoin(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')

        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [8], 'BTC', 'USDT', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_single_trade(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 11, 0)]

class TestOkex(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')

        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [7], 'BTC', 'USDT', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_single_trade(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 11, 0)]

class TestKraken(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')

        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [6], 'BTC', 'USDT', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_single_trade(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 11, 0)]

class TestCoinbase(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')

        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [5], 'BTC', 'USDT', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_single_trade(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 11, 0)]

class TestHuobi(TestMethod):
    @pytest.fixture
    def ptb(self, monkeypatch, spot_client, usdm_client, pricer):
        monkeypatch.setattr(SpreadLeg, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(SpreadLeg, 'name_of', lambda _, account_id: 'AAA')

        spot_client.add_books(
            [[100, 10, 12, 100],
            [100, 9, 11, 100]]
        )
        usdm_client.add_books(
            [[100, 9, 11, 100]]
        )
        with PairTradingBot(
            [4], 'BTC', 'USDT', -999, {},logger=logging.getLogger(), primary_client=spot_client, pair_client=usdm_client, pricer=pricer, 
        ) as ptb:
            yield ptb


    def test_single_trade(self, ptb, spot_client: FakeClient, usdm_client):
        ptb.config = {
            "quantity": 20, "slice_size": 10, "side": "BUY", "order_type": "LIMIT", "distance_to_tob": "TAKING",
            "pair_leg": { "account_id": 1, "base": "ABC", "quote": "USDT", "side": "SELL", "order_type": "LIMIT", "distance_to_tob": "TAKING"},
            "spread_params": { "start_if": "SPREAD_BIGGER_THAN", "start_threshold": 0.0016, "suspend_if": "NO_CONDITION","suspend_threshold": 0}
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        spot_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        ptb.run()
        spot_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000),'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == []
        
        usdm_client.order_results[0] = [{ 'state': 'AO', 'dealt': '0', 'remaining_amount': '10', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        ptb.run()
        usdm_client.order_results[0] = [{ 'state': 'FO', 'dealt': '10', 'remaining_amount': '0', 'create_time': str(time.time() * 1000), 'update_time': str(time.time() * 1000)}]
        time.sleep(1)
        assert spot_client.orders_placed == [(BUY, 'BTCUSDT', 11, 10, 0)]
        assert usdm_client.orders_placed == [(SELL, 'ABCUSDT', 9, 11, 0)]
