from altonomy.core.AccountBalance import AccountBalance
import logging
import math
import time
from typing import NamedTuple

import pytest
from altonomy.core.Order import Order
from altonomy.core.OrderBook import LegacyOrderBook
from altonomy.core.Side import BUY, SELL
from altonomy.apl_bots.TWAPBot import TWAPBot, BotStatus
from altonomy.ref_data_api.api import InstrumentData

logger = logging.getLogger()


class PlacedOrder(NamedTuple):
    side: str
    pair: str
    price: float
    amount: float
    order_id: int


class FakeClient:
    def __init__(self, pair):
        self.pair = pair
        self._orderbooks = []
        self.orderbook_index = 0
        self.orders_placed = []
        self.orders_canceled = []
        self.order_results = {}
        self.order_result_iterator = {}
        self.account_balance = {}
        self.get_orderbook = self.orderbook

    def orderbook(self, *args, **kwargs):
        if self.orderbook_index < len(self._orderbooks):
            bb_size, bb_price, ba_price, ba_size = \
                self._orderbooks[self.orderbook_index]

            ob = LegacyOrderBook(
                {
                    self.pair: {
                        'asks': [
                            {'price': ba_price, 'volume': ba_size}
                        ],
                        'bids': [
                            {'price': bb_price, 'volume': bb_size}
                        ],
                    }
                }
            )
        else:
            ob = LegacyOrderBook(
                {
                    self.pair: {
                        'asks': [],
                        'bids': [],
                    }
                }
            )
        self.orderbook_index += 1
        ob.timestamp = time.time()
        logger.info(f'returned orderbook {ob}')
        return ob

    def add_books(self, bbos: list = [[0, 0, 0, 0]]):
        for bbo in bbos:
            self._orderbooks.insert(len(self._orderbooks), bbo)

    def buy(self, pair, price, size, order_type, account_id=None, remark=''):
        logger.info(f'placed buy order {pair} {price} {size} {remark}')
        order_id = len(self.orders_placed) + 1
        self.orders_placed.append(
            PlacedOrder(BUY, pair, price, size, order_id))
        return order_id

    def sell(self, pair, price, size, order_type, account_id=None, remark=''):
        logger.info(f'placed sell order {pair} {price} {size} {remark}')
        order_id = len(self.orders_placed) + 1
        self.orders_placed.append(
            PlacedOrder(SELL, pair, price, size, order_id))
        return order_id

    def cancel(self, order_id, remark=''):
        logger.info(f'cancel order {order_id}')
        self.orders_canceled.append(order_id)

    def get_order_details(self, *, order_id, **kwargs):
        side, pair, price, amount, order_id = next(
            order for order in self.orders_placed if order[4] == order_id
        )

        try:
            order_results = next(
                self.order_result_iterator[order_id],
                self.order_results[order_id][-1]
            )
        except KeyError:
            self.order_result_iterator[order_id] = \
                iter(self.order_results[order_id])
            order_results = next(self.order_result_iterator[order_id])

        od = {
            'order_ref': order_id,
            'pair': pair,
            'side': side,
            'price': price,
            'size': amount,
            **order_results,
        }
        logger.info(f'retrieved order details {od}')
        return Order(od)

    def client(self):
        return self

    def get_exchange_config(self, *args, **kwargs):
        return

    def get_account_config(self, config, account_id):
        configs = {
            0: {'is_futures': 'False',
                'dual_side_position': 'False', 'exchange_name': 'Binance'},
            1: {'is_futures': 'True',
                'dual_side_position': 'False', 'exchange_name': 'Binancedm'},
            2: {'is_futures': 'True',
                'dual_side_position': 'True', 'exchange_name': 'Binancedmx'},
            3: {'is_futures': 'False',
                'dual_side_position': 'False', 'exchange_name': 'Binance'},
            4: {'is_futures': 'False',
                'dual_side_position': 'False', 'exchange_name': 'Huobi'},
            5: {'is_futures': 'False',
                'dual_side_position': 'False', 'exchange_name': 'Coinbase'},
            6: {'is_futures': 'False',
                'dual_side_position': 'False', 'exchange_name': 'Kraken'},
            7: {'is_futures': 'False',
                'dual_side_position': 'False', 'exchange_name': 'Okex'},
            8: {'is_futures': 'False',
                'dual_side_position': 'False', 'exchange_name': 'Kucoin'},
            '': {
                'is_futures': 'False',
                'dual_side_position': 'False',
                'exchange_name': 'None'}}

        return configs[account_id][config]

    def get_account_balance(self, account_id, **kwargs):
        inf_balance = AccountBalance()
        inf_balance['ABC'].available = math.inf
        inf_balance['PQR'].available = math.inf
        inf_balance['XYZ'].available = math.inf
        inf_balance['BTC'].available = math.inf
        inf_balance['USDT'].available = math.inf
        inf_balance['ABCUSDT Long'].available = math.inf
        inf_balance['ABCUSDT Short'].available = math.inf
        inf_balance['ABCUSD_PERP Long'].available = math.inf
        inf_balance['ABCUSD_PERP Short'].available = math.inf
        return self.account_balance.get(account_id, inf_balance)

    def get_product_leverage(self, pair, account_id, **kwargs):
        return 10

    def instrument_data(self, **kwargs):
        return FakeInstrumentDataSession()

    def register_resource_usage(self, type, exchange, pair):
        pass

    def deregister_resource_usage(self, type, exchange, pair):
        pass

    def exchange_name(self, name):
        return name


class FakeInstrumentDataSession:
    def get_active_instruments_for_exchange(self, exchange_id):
        ins_spot = InstrumentData()
        ins_spot.altonomy_symbol = 'ABC/XYZ-S'
        ins_spot.exchange_symbol = 'ABCXYZ'
        ins_spot.settlement_asset = 'XYZ'
        ins_spot.quote_coin = 'XYZ'
        ins_spot.min_order_notional = 10
        ins_spot.min_order_size = 1
        ins_spot.size_precision = 1
        ins_spot.tick_size = 1

        ins_spot2 = InstrumentData()
        ins_spot2.altonomy_symbol = 'PQR/XYZ-S'
        ins_spot2.exchange_symbol = 'PQRXYZ'
        ins_spot2.settlement_asset = 'XYZ'
        ins_spot2.quote_coin = 'XYZ'
        ins_spot2.min_order_notional = 10
        ins_spot2.min_order_size = 1
        ins_spot2.size_precision = 1
        ins_spot2.tick_size = 1

        ins_spot3 = InstrumentData()
        ins_spot3.altonomy_symbol = 'ABC/USD-S'
        ins_spot3.exchange_symbol = 'ABCUSD'
        ins_spot3.settlement_asset = 'USD'
        ins_spot3.quote_coin = 'USD'
        ins_spot3.min_order_notional = 10
        ins_spot3.min_order_size = 1
        ins_spot3.size_precision = 1
        ins_spot3.tick_size = 1

        ins_usd_fut = InstrumentData()
        ins_usd_fut.altonomy_symbol = 'ABC/USDT-P/USDT'
        ins_usd_fut.exchange_symbol = 'ABCUSDT'
        ins_usd_fut.settlement_asset = 'USDT'
        ins_usd_fut.quote_coin = 'USDT'
        ins_usd_fut.min_order_notional = 10
        ins_usd_fut.min_order_size = 1
        ins_usd_fut.size_precision = 1
        ins_usd_fut.tick_size = 1

        ins_usd_fut2 = InstrumentData()
        ins_usd_fut2.altonomy_symbol = 'LMN/BUSD-P/BUSD'
        ins_usd_fut2.exchange_symbol = 'LMNBUSD'
        ins_usd_fut2.settlement_asset = 'BUSD'
        ins_usd_fut2.quote_coin = 'BUSD'
        ins_usd_fut2.min_order_notional = 10
        ins_usd_fut2.min_order_size = 1
        ins_usd_fut2.size_precision = 1
        ins_usd_fut2.tick_size = 1

        ins_coin_fut = InstrumentData()
        ins_coin_fut.altonomy_symbol = 'ABC/USD-P/COIN'
        ins_coin_fut.exchange_symbol = 'ABCUSD_PERP'
        ins_coin_fut.settlement_asset = 'ABC'
        ins_coin_fut.quote_coin = 'USD'
        ins_coin_fut.contract_size = 10
        ins_coin_fut.min_order_notional = 10
        ins_coin_fut.min_order_size = 1
        ins_coin_fut.size_precision = 1
        ins_coin_fut.tick_size = 1

        huobi = InstrumentData()
        huobi.altonomy_symbol = 'BTC/USDT-S'
        huobi.exchange_symbol = 'btcusdt'
        huobi.settlement_asset = 'USDT'
        huobi.quote_coin = 'USDT'
        huobi.min_order_notional = 10
        huobi.min_order_size = 1
        huobi.size_precision = 1
        huobi.tick_size = 1

        coinbase = InstrumentData()
        coinbase.altonomy_symbol = 'BTC/USDT-S'
        coinbase.exchange_symbol = 'BTC-USDT'
        coinbase.settlement_asset = 'USDT'
        coinbase.quote_coin = 'USDT'
        coinbase.min_order_notional = 10
        coinbase.min_order_size = 1
        coinbase.size_precision = 1
        coinbase.tick_size = 1

        kraken = InstrumentData()
        kraken.altonomy_symbol = 'BTC/USDT-S'
        kraken.exchange_symbol = 'XBTUSDT'
        kraken.settlement_asset = 'USDT'
        kraken.quote_coin = 'USDT'
        kraken.min_order_notional = None
        kraken.min_order_size = 1
        kraken.size_precision = 1
        kraken.tick_size = 1

        okex = InstrumentData()
        okex.altonomy_symbol = 'BTC/USDT-S'
        okex.exchange_symbol = 'BTC-USDT'
        okex.settlement_asset = 'USDT'
        okex.quote_coin = 'USDT'
        okex.min_order_notional = None
        okex.min_order_size = 1
        okex.size_precision = 1
        okex.tick_size = 1

        kucoin = InstrumentData()
        kucoin.altonomy_symbol = 'BTC/USDT-S'
        kucoin.exchange_symbol = 'BTC-USDT'
        kucoin.settlement_asset = 'USDT'
        kucoin.quote_coin = 'USDT'
        kucoin.min_order_notional = None
        kucoin.min_order_size = 1
        kucoin.size_precision = 1
        kucoin.tick_size = 1

        return [
            ins_spot, ins_spot2, ins_spot3, ins_usd_fut, ins_usd_fut2,
            ins_coin_fut, huobi, coinbase, kraken, okex, kucoin
            ]


@pytest.fixture(autouse=True)
def set_log_cap_level(caplog):
    caplog.set_level(logging.DEBUG)


@pytest.fixture
def spot_client():
    return FakeClient('ABCXYZ')


@pytest.fixture
def spot_client_2():
    return FakeClient('PQRXYZ')


@pytest.fixture
def usdm_client():
    return FakeClient('ABCUSDT')


@pytest.fixture
def coin_client():
    return FakeClient('ABCUSD_PERP')


class TestMethod:
    @pytest.fixture(scope="class")
    def monkeyclass(self):
        """Class scoped monkeypatch"""
        mpatch = pytest.MonkeyPatch()
        yield mpatch
        mpatch.undo


class TestBasicValidation(TestMethod):
    @pytest.fixture
    def twapbot(self, monkeypatch, spot_client):
        monkeypatch.setattr(TWAPBot, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(TWAPBot, 'name_of', lambda _, account_id: 'AAA')

        spot_client.add_books(
            [
                [100, 10, 12, 100],
                [100, 9, 11, 100]
            ]
        )
        config = {
            "quantity": "1.0", "last_updated": "1642503271.523931",
            "duration": "300", "side": "BUY", "instrument_type": "SPOT"
        }

        with TWAPBot(
            0, 'ABC', 'XYZ', -999, config, logger=logging.getLogger(),
            alt_client=spot_client
        ) as twapbot:
            yield twapbot

    def test_config_format(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "0.1", "last_updated": "1642503271.523931",
            "duration": "300", "side": "BUY", "instrument_type": "SPOT"
        }

        twapbot.run()
        assert twapbot.position['Status'] ==  \
            "Total Qty(0.1) must be gt Min Order Qty(1)"


class TestBotStatus(TestMethod):
    @pytest.fixture
    def twapbot(self, monkeypatch, spot_client):
        monkeypatch.setattr(TWAPBot, 'exchange_id_of', lambda _, account_id: 2)
        monkeypatch.setattr(TWAPBot, 'name_of', lambda _, account_id: 'AAA')

        spot_client.add_books(
            [
                [100, 10, 12, 100],
                [100, 9, 11, 100]
            ]
        )

        config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT"
        }

        with TWAPBot(
            0, 'ABC', 'XYZ', -999, config, logger=logging.getLogger(),
            alt_client=spot_client
        ) as twapbot:
            yield twapbot

    def test_order_status(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        # sends an order and is accepted
        spot_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0',
            'remaining_amount': '2', 'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()

        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.ORDER_SUBMITTED

        time.sleep(twapbot.default_post_frequency+1)
        # order_id (0) is cancelled
        # order_id (1) is accepted
        spot_client.order_results[1] = [{
            'state': 'CO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        spot_client.order_results[2] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()

        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.ORDER_SUBMITTED

        # order_id (1) is filled
        spot_client.order_results[2] = [{
            'state': 'FO', 'dealt': '2', 'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        time.sleep(1)
        twapbot.run()

        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.STRATEGY_COMPLETED
        assert not twapbot.reason

    def test_balance(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT"
        }
        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['XYZ'].available = 1
        spot_client.account_balance[0] = low_balance

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE

    def test_single_maker_trade(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT",
            "threshold_price": "-1"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        # sends an order and is accepted
        spot_client.order_results[1] = [
            {
                'state': 'AO', 'dealt': '0',
                'remaining_amount': '2',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000)
            }
        ]
        twapbot.run()
        spot_client.order_results[1] = [
            {
                'state': 'FO', 'dealt': '2', 'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000)
            }
        ]

        assert spot_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCXYZ', 9, 2, 1)

    def test_threshold_price_breach(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT",
            "threshold_price": "8.0"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.THRESHOLD_PRICE_BREACH

    def test_satisfy_threshold_price(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT",
            "threshold_price": "10.1"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        # sends an order and is accepted
        spot_client.order_results[1] = [
            {
                'state': 'AO', 'dealt': '0',
                'remaining_amount': '2',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000)
            }
        ]
        twapbot.run()
        spot_client.order_results[1] = [
            {
                'state': 'FO', 'dealt': '2', 'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000)
            }
        ]

        assert spot_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCXYZ', 9, 2, 1)

    def test_taker_trade_no_prev_fills(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )

        # sends an order and is accepted and then cancelled
        spot_client.order_results[1] = [
            {
                'state': 'AO', 'dealt': '0',
                'remaining_amount': '2',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000)
            }
        ]
        twapbot.run()
        spot_client.order_results[1] = [
            {
                'state': 'CO', 'dealt': '0',
                'remaining_amount': '2',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000)
            }
        ]

        time.sleep(twapbot.default_post_frequency+1)
        spot_client.order_results[2] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        assert spot_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCXYZ', 9, 2, 1)
        assert spot_client.orders_placed[1] == PlacedOrder(
            BUY, 'ABCXYZ', 12, 2, 2)

    def test_taker_trade_prev_partial_fills(
            self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )

        # sends an order and partially filled
        spot_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        spot_client.order_results[1] = [{
            'state': 'CO', 'dealt': '1', 'remaining_amount': '1',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]

        time.sleep(twapbot.default_post_frequency+1)
        spot_client.order_results[2] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '1',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        assert spot_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCXYZ', 9, 2, 1)
        assert spot_client.orders_placed[1] == PlacedOrder(
            BUY, 'ABCXYZ', 12, 1, 2)

    def test_order_failed(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )

        # sends an order and failed
        spot_client.order_results[1] = [{
            'state': 'OR', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        time.sleep(twapbot.default_post_frequency+1)
        spot_client.order_results[2] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        assert spot_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCXYZ', 9, 2, 1)
        assert spot_client.orders_placed[1] == PlacedOrder(
            BUY, 'ABCXYZ', 12, 2, 2)

    def test_balance_spot_buy(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "SPOT"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['XYZ'].available = 1
        spot_client.account_balance[0] = low_balance

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE

        enough_balance = AccountBalance()
        enough_balance['XYZ'].available = 20
        spot_client.account_balance[0] = enough_balance

        spot_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        spot_client.order_results[1] = [{
            'state': 'FO', 'dealt': '2', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]

        assert spot_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCXYZ', 10, 2, 1)

    def test_balance_spot_sell(self, twapbot, spot_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "SELL", "instrument_type": "SPOT"
        }

        spot_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['ABC'].available = 1
        spot_client.account_balance[0] = low_balance

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE

        enough_balance = AccountBalance()
        enough_balance['ABC'].available = 20
        spot_client.account_balance[0] = enough_balance

        spot_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        time.sleep(1)
        spot_client.order_results[1] = [{
            'state': 'FO', 'dealt': '2', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]

        assert spot_client.orders_placed[0] == PlacedOrder(
            SELL, 'ABCXYZ', 12, 2, 1)


class TestFuturesBotStatus(TestMethod):
    @pytest.fixture
    def twapbot(self, monkeypatch, usdm_client):
        monkeypatch.setattr(TWAPBot, 'exchange_id_of', lambda _, account_id: 1)
        monkeypatch.setattr(TWAPBot, 'name_of', lambda _, account_id: 'AAA')

        usdm_client.add_books(
            [
                [100, 10, 12, 100],
                [100, 9, 11, 100]
            ]
        )

        config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "FUTURES"
        }

        with TWAPBot(
            0, 'ABC', 'USDT', -999, config, logger=logging.getLogger(),
            alt_client=usdm_client
        ) as twapbot:
            yield twapbot

    def test_future_order_status(self, twapbot, usdm_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "FUTURES"
        }

        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        # sends an order and is accepted
        usdm_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0',
            'remaining_amount': '2', 'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()

        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.ORDER_SUBMITTED

        time.sleep(twapbot.default_post_frequency+1)
        # order_id (0) is cancelled
        # order_id (1) is accepted
        usdm_client.order_results[1] = [{
            'state': 'CO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        usdm_client.order_results[2] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()

        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.ORDER_SUBMITTED

        # order_id (1) is filled
        usdm_client.order_results[2] = [{
            'state': 'FO', 'dealt': '2', 'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        time.sleep(1)
        twapbot.run()

        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.STRATEGY_COMPLETED
        assert not twapbot.reason

    def test_future_balance(self, twapbot, usdm_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "FUTURES"
        }
        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   10, 12, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['ABCUSDT Short'].available = 1
        usdm_client.account_balance[0] = low_balance

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE

    def test_future_single_maker_trade(self, twapbot, usdm_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "FUTURES"
        }

        usdm_client.add_books(
            [
                [100,   10, 12, 100],
                [100,   10, 12, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100],
                [100,   9,  13, 100]
            ]
        )
        # sends an order and is accepted
        usdm_client.order_results[1] = [
            {
                'state': 'AO', 'dealt': '0',
                'remaining_amount': '2',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000)
            }
        ]
        twapbot.run()
        usdm_client.order_results[1] = [
            {
                'state': 'FO', 'dealt': '2', 'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000)
            }
        ]

        assert usdm_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCUSDT', 9, 2, 1)

    def test_balance_futures_buy(self, twapbot, usdm_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "FUTURES"
        }

        usdm_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['ABCUSDT Short'].available = 1
        usdm_client.account_balance[0] = low_balance

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE

        enough_balance = AccountBalance()
        enough_balance['ABCUSDT Short'].available = 20
        usdm_client.account_balance[0] = enough_balance

        usdm_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        usdm_client.order_results[1] = [{
            'state': 'FO', 'dealt': '2', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]

        assert usdm_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCUSDT', 10, 2, 1)

    def test_balance_futures_sell(self, twapbot, usdm_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "SELL", "instrument_type": "FUTURES"
        }

        usdm_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['ABCUSDT Long'].available = 1
        usdm_client.account_balance[0] = low_balance

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE

        enough_balance = AccountBalance()
        enough_balance['ABCUSDT Long'].available = 20
        usdm_client.account_balance[0] = enough_balance

        usdm_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        time.sleep(1)
        usdm_client.order_results[1] = [{
            'state': 'FO', 'dealt': '2', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]

        assert usdm_client.orders_placed[0] == PlacedOrder(
            SELL, 'ABCUSDT', 12, 2, 1)


class TestCoinFuturesBotStatus(TestMethod):
    @pytest.fixture
    def twapbot(self, monkeypatch, coin_client):
        monkeypatch.setattr(TWAPBot, 'exchange_id_of', lambda _, account_id: 1)
        monkeypatch.setattr(TWAPBot, 'name_of', lambda _, account_id: 'AAA')

        coin_client.add_books(
            [
                [100, 10, 12, 100],
                [100, 9, 11, 100]
            ]
        )

        config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "FUTURES"
        }

        with TWAPBot(
            0, '', 'ABCUSD_PERP', -999, config, logger=logging.getLogger(),
            alt_client=coin_client
        ) as twapbot:
            yield twapbot

    def test_balance_coin_futures_buy(self, twapbot, coin_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "BUY", "instrument_type": "FUTURES"
        }

        coin_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['ABCUSD_PERP Short'].available = 1
        coin_client.account_balance[0] = low_balance

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE

        enough_balance = AccountBalance()
        enough_balance['ABCUSD_PERP Short'].available = 20
        coin_client.account_balance[0] = enough_balance

        coin_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        time.sleep(1)
        coin_client.order_results[1] = [{
            'state': 'FO', 'dealt': '2', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]

        assert coin_client.orders_placed[0] == PlacedOrder(
            BUY, 'ABCUSD_PERP', 10, 2, 1)

    def test_balance_coin_futures_sell(self, twapbot, coin_client: FakeClient):
        twapbot.config = {
            "quantity": "2", "last_updated": "1642503271.523931",
            "duration": "10", "side": "SELL", "instrument_type": "FUTURES"
        }

        coin_client.add_books(
            [
                [100,   10, 12, 100]
            ]
        )
        low_balance = AccountBalance()
        low_balance['ABCUSD_PERP Long'].available = 1
        coin_client.account_balance[0] = low_balance

        twapbot.run()
        assert not twapbot.last_error
        assert twapbot.bot_status == BotStatus.NOT_ENOUGH_BALANCE

        enough_balance = AccountBalance()
        enough_balance['ABCUSD_PERP Long'].available = 20
        coin_client.account_balance[0] = enough_balance

        coin_client.order_results[1] = [{
            'state': 'AO', 'dealt': '0', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]
        twapbot.run()
        time.sleep(1)
        coin_client.order_results[1] = [{
            'state': 'FO', 'dealt': '2', 'remaining_amount': '2',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000)}
        ]

        assert coin_client.orders_placed[0] == PlacedOrder(
            SELL, 'ABCUSD_PERP', 12, 2, 1)
