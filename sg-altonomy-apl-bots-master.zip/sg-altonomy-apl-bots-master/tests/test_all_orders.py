from altonomy.apl_bots.CoinClerk import CoinClerk
import logging
import datetime
from types import SimpleNamespace

end_time = datetime.datetime.now(datetime.timezone.utc)
start_time = end_time - datetime.timedelta(hours=24)

CoinClerk.connect_to_DBserver = lambda *args, **kwargs: None

cc = CoinClerk(logger=logging.getLogger())
order = {
    'OrderID': '5e72c477-1e4d-11e9-9ec7-00e04c3600d7;2.104;11692.4868;bid',
    'TimeStamp': 1596472381856,
    'TradingPair': 'WIKENKRW',
    'Exchange': 'Coinone',
    'AccountKey': '566',
    'LongShort': 'Long',
    'Amount': 11692.486799999999,
    'FilledAmount': 6634.981,
    'Price': 2.104,
    'Status': 'Completed',
    'BuyCommission': -1,
    'SellCommission': -1,
    'NetFilledAmount': -1,
    'NetFilledCashAmount': -1,
    'FilledCashAmount': 13960.000024,
}
cc.insert_execution_order_sqla(dict(order.items()))
cc.insert_execution_order_sqla(order.items())

print(
    cc.get_historical_execution_aggregates_sqla(
        'SHR-DB6BNB', 'BinanceDex', None, start_time, end_time
    )
)
output = [SimpleNamespace(**o.__dict__) for o in cc.all_orders()]
print(output)
output[0].Amount = 0
print([SimpleNamespace(**o.__dict__) for o in cc.all_orders()])

