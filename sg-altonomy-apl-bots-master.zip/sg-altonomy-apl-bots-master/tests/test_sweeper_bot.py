import math
import time

from setuptools import monkey
from altonomy.apl_bots.SweeperBot import SweeperBot
import asyncio
import logging
from datetime import datetime
import threading
from typing import Callable, Iterable, List, NamedTuple, NewType, Tuple
from uuid import uuid4

import pytest
import altonomy.core as core
from altonomy.core.Order import Order
from altonomy.core.OrderBook import OrderBook, UDSOrderBook
from altonomy.core.AccountBalance import AccountBalance
from altonomy.core.Side import BUY, SELL, Side
from altonomy.apl_bots.SniperBot import SniperBot

Price = NewType('Price', float)
Amount = NewType('Amount', float)
PriceLevel = NewType('PriceLevel', Tuple[Price, Amount])
Asks = NewType('Asks', Iterable[PriceLevel])
Bids = NewType('Bids', Iterable[PriceLevel])

logger = logging.getLogger()


class PlacedOrder(NamedTuple):
    side: str
    pair: str
    price: float
    amount: float
    order_id: int
    account: int


class FakeClient:
    class Orderbook(NamedTuple):
        asks: Iterable
        bids: Iterable

    def __init__(self, pair):
        self.pair = pair
        self.orderbook = {}
        self.orders_placed = []
        self.orders_canceled = []
        self.order_results = {}
        self.order_result_iterator = {}
        self.account_balance = {}

    def buy(self, pair, price, size, account_id=None, remark=None):
        assert price > 0
        assert size > 0
        logger.info(f'placed buy order {pair} {price} {size} for {account_id}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(
            PlacedOrder(BUY, pair, price, size, order_id, account=account_id)
        )
        return order_id

    def sell(self, pair, price, size, account_id=None, remark=None):
        assert price > 0
        assert size > 0
        logger.info(f'placed sell order {pair} {price} {size}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(
            PlacedOrder(SELL, pair, price, size, order_id, account=account_id)
        )
        return order_id

    def cancel(self, order_id):
        logger.info(f'cancel order {order_id}')
        self.orders_canceled.append(order_id)

    def get_order_details(self, *, order_id, **kwargs):
        side, pair, price, amount, order_id, account = next(
            order for order in self.orders_placed if order[4] == order_id
        )

        try:
            order_results = next(
                self.order_result_iterator[order_id], self.order_results[order_id][-1]
            )
        except KeyError:
            self.order_result_iterator[order_id] = iter(self.order_results[order_id])
            order_results = next(self.order_result_iterator[order_id])

        od = {
            'order_ref': order_id,
            'pair': pair,
            'side': side,
            'price': price,
            'size': amount,
            'account': account,
            **order_results,
        }
        logger.info(f'retrieved order details {od}')
        return Order(od)

    def get_exchange_config(self, *args, **kwargs):
        return

    def subscribe_streams(self, streams):
        logger.info(f'subsribed to {streams}')
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        stop_event = asyncio.Event()

        exchange, pair, _stream_id, callback, *additional_args = streams[0]

        def mock_l2_detailed(pair, stop_event, callback, *args, **kwargs):
            while not stop_event.is_set():
                if not self.orderbook[exchange].timestamp:
                    self.orderbook[exchange].timestamp = datetime.utcnow().timestamp()
                self.orderbook[exchange].status = 1
                callback(*self.orderbook[exchange])
                time.sleep(0.1)

        thread = threading.Thread(
            target=mock_l2_detailed, args=(pair, stop_event, callback)
        )
        thread.daemon = True
        thread.start()
        return stop_event

    def get_account_balance(self, account_id):
        inf_balance = AccountBalance()
        inf_balance['ABC'].available = math.inf
        inf_balance['XYZ'].available = math.inf
        return self.account_balance.get(account_id, inf_balance)


PAIR = 'ABCXYZ'


@pytest.fixture(autouse=True)
def set_log_cap_level(caplog):
    caplog.set_level(logging.DEBUG)


@pytest.fixture
def client():
    fake_client = FakeClient(PAIR)

    fake_client.orderbook[0] = UDSOrderBook(pair=PAIR, source=0)
    for i in range(30, 40):
        fake_client.orderbook[0].asks.add_level(i, 10)
    for i in range(10, 21):
        fake_client.orderbook[0].bids.add_level(i, 10)
    fake_client.orderbook[1] = UDSOrderBook(pair=PAIR, source=1)
    for i in range(32, 40):
        fake_client.orderbook[1].asks.add_level(i, 10)
    for i in range(12, 19):
        fake_client.orderbook[0].bids.add_level(i, 10)
    return fake_client


@pytest.fixture
def sb(monkeypatch, client):
    monkeypatch.setattr(SweeperBot, 'exchange_name_of', lambda _, x: x)
    monkeypatch.setattr(SweeperBot, 'exchange_id_of', lambda _, x: x)
    monkeypatch.setattr(SweeperBot, 'name_of', lambda _, x: x)
    with SweeperBot(
        [0, 1], 'ABC', 'XYZ', alt_client=client, logger=logging.getLogger()
    ) as sb:
        sb.delay = 0
        sb.config = {
            'totalAmount': 20,
            'side': 'buy',
        }
        yield sb


def test_load_config(sb):
    logger.info(sb.config)
    assert sb.config
    assert sb.config_is_valid
    assert sb.pair == 'ABCXYZ'
    print(sb.client)
    assert sb.client
    assert sb.client.buy
    assert sb.client.sell
    assert sb.client.orderbook
    assert sb.send_order
    assert sb.accounts == [0, 1]


def test_single_order_book(sb, client: FakeClient):
    client.order_results[0] = [
        {
            'state': 'FO',
            'dealt': '20',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    sb.run()
    time.sleep(0.3)
    print(client.orders_placed)
    assert client.orders_placed == [
        PlacedOrder(
            side=BUY, pair='ABCXYZ', price=31, amount=20.0, order_id=0, account=0
        )
    ]


def test_order_book_outdated(sb, client: FakeClient):
    client.orderbook[1].asks.add_level(29, 10)
    client.orderbook[1].timestamp = datetime.utcnow().timestamp() - 999
    client.order_results[0] = [
        {
            'state': 'FO',
            'dealt': '20',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    sb.run()
    time.sleep(0.3)
    print(client.orders_placed)
    assert client.orders_placed == [
        PlacedOrder(
            side=BUY, pair='ABCXYZ', price=31, amount=20.0, order_id=0, account=0
        )
    ]


def test_spread_orders(sb, client: FakeClient):
    client.orderbook[1].asks.add_level(29, 10)
    client.order_results[0] = [
        {
            'state': 'FO',
            'dealt': '10',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    client.order_results[1] = [
        {
            'state': 'FO',
            'dealt': '10',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    time.sleep(0.3)
    sb.run()
    time.sleep(0.3)
    print(client.orders_placed)
    assert client.orders_placed == [
        PlacedOrder(
            side=BUY, pair='ABCXYZ', price=29, amount=10.0, order_id=0, account=1
        ),
        PlacedOrder(
            side=BUY, pair='ABCXYZ', price=30, amount=10.0, order_id=1, account=0
        ),
    ]


def test_no_balance(sb, client: FakeClient):
    client.orderbook[1].asks.add_level(29, 20)
    empty_balance = AccountBalance()
    client.account_balance[1] = empty_balance
    client.order_results[0] = [
        {
            'state': 'FO',
            'dealt': '20',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    sb.run()
    time.sleep(0.3)
    assert client.orders_placed == [
        PlacedOrder(
            side=BUY, pair='ABCXYZ', price=31, amount=20.0, order_id=0, account=0
        )
    ]


def test_up_to_balance(sb, client: FakeClient):
    client.orderbook[1].asks.add_level(29, 20)
    partial_balance = AccountBalance()
    partial_balance['XYZ'].available = 29 * 6
    client.account_balance[1] = partial_balance
    client.order_results[0] = [
        {
            'state': 'FO',
            'dealt': '6',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    client.order_results[1] = [
        {
            'state': 'FO',
            'dealt': '14',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    time.sleep(0.3)
    sb.run()
    time.sleep(0.3)
    print(client.orders_placed)
    assert client.orders_placed == [
        PlacedOrder(
            side=BUY, pair='ABCXYZ', price=29, amount=6.0, order_id=0, account=1
        ),
        PlacedOrder(
            side=BUY, pair='ABCXYZ', price=31, amount=14.0, order_id=1, account=0
        ),
    ]


def test_up_to_balance_sell(sb, client: FakeClient):
    sb.side = SELL
    client.orderbook[1].bids.add_level(21, 20)
    partial_balance = AccountBalance()
    partial_balance['ABC'].available = 6
    client.account_balance[1] = partial_balance
    client.order_results[0] = [
        {
            'state': 'FO',
            'dealt': '6',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    client.order_results[1] = [
        {
            'state': 'FO',
            'dealt': '14',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    time.sleep(0.3)
    sb.run()
    time.sleep(0.3)
    print(client.orders_placed)
    assert client.orders_placed == [
        PlacedOrder(
            side=SELL, pair='ABCXYZ', price=21, amount=6.0, order_id=0, account=1
        ),
        PlacedOrder(
            side=SELL, pair='ABCXYZ', price=19, amount=14.0, order_id=1, account=0
        ),
    ]


def test_ignore_pending(sb: SweeperBot, client: FakeClient):
    client.orderbook[1].bids.add_level(29, 20)
    client.orders_placed.append(PlacedOrder(BUY, PAIR, 29, 6, 0, 1))
    client.order_results[0] = [
        {
            'state': 'AO',
            'dealt': '0',
            'remaining_amount': '6',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
            'create_time': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S.%f'),
        }
    ]
    sb.order_monitor.open_orders[0] = client.get_order_details(order_id=0)
    client.order_results[1] = [
        {
            'state': 'FO',
            'dealt': '14',
            'remaining_amount': '0',
            'create_time': str(time.time() * 1000),
            'update_time': str(time.time() * 1000),
        }
    ]
    time.sleep(0.3)
    sb.run()
    time.sleep(0.3)
    print(client.orders_placed)
    assert client.orders_placed == [
        PlacedOrder(side=BUY, pair='ABCXYZ', price=29, amount=6, order_id=0, account=1),
        PlacedOrder(
            side=BUY, pair='ABCXYZ', price=31, amount=14.0, order_id=1, account=0
        ),
    ]
