from altonomy.core.AccountBalance import AccountBalance
from altonomy.apl_bots.OrderMonitor import OrderMonitor
import logging
import math
import random
from datetime import datetime
import time
from traceback import clear_frames
from types import SimpleNamespace
from typing import Callable, Iterable, List, NamedTuple, NewType, Tuple
from uuid import uuid4

import pytest
import altonomy.core as core
from altonomy.core.Order import Order
from altonomy.core.OrderBook import LegacyOrderBook
from altonomy.core.Side import BUY, SELL, Side
from altonomy.apl_bots.SniperBot import SniperBot
from altonomy.ref_data_api.api import InstrumentData

Price = NewType('Price', float)
Amount = NewType('Amount', float)
PriceLevel = NewType('PriceLevel', Tuple[Price, Amount])
Asks = NewType('Asks', Iterable[PriceLevel])
Bids = NewType('Bids', Iterable[PriceLevel])

logger = logging.getLogger()


class PlacedOrder(NamedTuple):
    side: str
    pair: str
    price: float
    amount: float
    order_id: int


class FakeClient:
    class Orderbook(NamedTuple):
        asks: Iterable
        bids: Iterable

    def __init__(self, pair, initial_orderbook: Tuple[Asks, Bids]):
        self.pair = pair
        self._orderbook = FakeClient.Orderbook(
            sorted(initial_orderbook[0]), sorted(initial_orderbook[1], reverse=True),
        )
        self.orders_placed = []
        self.orders_canceled = []
        self.order_results = {}
        self.order_result_iterator = {}
        self.account_balance = {}
        self.get_orderbook = self.orderbook

    def orderbook(self, *args, **kwargs):
        ob = LegacyOrderBook(
            {
                self.pair: {
                    'asks': [
                        {'price': p, 'volume': v} for p, v in sorted(self._orderbook[0])
                    ],
                    'bids': [
                        {'price': p, 'volume': v}
                        for p, v in sorted(self._orderbook[1], reverse=True)
                    ],
                }
            }
        )
        ob.timestamp = time.time()
        logger.info(f'returned orderbook {ob}')
        return ob

    def add_price_level(self, side: Side, price, amount):
        if side == BUY:
            self._orderbook.bids.append((price, amount))
        elif side == SELL:
            self._orderbook.asks.append((price, amount))
        else:
            raise ValueError

    def deregister_resource_usage(self, resource_type: str, *args, remove: bool=False) -> bool:
                return True

    def exchange_name(self, name):
        return "TEST_EXCHANGE"

    def buy(self, pair, price, size, order_type, account_id=None, remark=None):
        logger.info(f'placed buy order {pair} {price} {size}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder(BUY, pair, price, size, order_id))
        return order_id

    def sell(self, pair, price, size, order_type, account_id=None, remark=None):
        logger.info(f'placed sell order {pair} {price} {size}')
        order_id = len(self.orders_placed)
        self.orders_placed.append(PlacedOrder(SELL, pair, price, size, order_id))
        return order_id

    def cancel(self, order_id):
        logger.info(f'cancel order {order_id}')
        self.orders_canceled.append(order_id)

    def get_order_details(self, *, order_id, **kwargs):
        side, pair, price, amount, order_id = next(
            order for order in self.orders_placed if order[4] == order_id
        )

        try:
            order_results = next(
                self.order_result_iterator[order_id], self.order_results[order_id][-1]
            )
        except KeyError:
            self.order_result_iterator[order_id] = iter(self.order_results[order_id])
            order_results = next(self.order_result_iterator[order_id])

        od = {
            'order_ref': order_id,
            'pair': pair,
            'side': side,
            'price': price,
            'size': amount,
            **order_results,
        }
        logger.info(f'retrieved order details {od}')
        return Order(od)

    def client(self):
        return self

    def get_exchange_config(self, *args, **kwargs):
        return

    def get_account_balance(self, account_id, **kwargs):
        inf_balance = AccountBalance()
        inf_balance['ABC'].available = math.inf
        inf_balance['XYZ'].available = math.inf
        inf_balance['ABCUSDT Long'].available = math.inf
        inf_balance['ABCUSDT Short'].available = math.inf
        return self.account_balance.get(account_id, inf_balance)

    def get_product_leverage(self, pair, account_id, **kwargs):
        return 10

    def instrument_data(self, **kwargs):
        return FakeInstrumentDataSession()

class FakeInstrumentDataSession:
    def get_active_instruments_for_exchange(self, exchange_id):
        ins_spot = InstrumentData()
        ins_spot.altonomy_symbol = 'ABC/XYZ-S'
        ins_spot.exchange_symbol = 'ABCXYZ'
        ins_spot.settlement_asset = 'XYZ'

        ins_usd_fut = InstrumentData()
        ins_usd_fut.altonomy_symbol = 'ABC/USDT-P/USDT'
        ins_usd_fut.exchange_symbol = 'ABCUSDT'
        ins_usd_fut.settlement_asset = 'USDT'

        ins_coin_fut = InstrumentData()
        ins_coin_fut.altonomy_symbol = 'ABC/USD-P/COIN'
        ins_coin_fut.exchange_symbol = 'ABCUSD_PERP'
        ins_coin_fut.settlement_asset = 'ABC'
        ins_coin_fut.contract_size = 10

        return [ins_spot, ins_usd_fut, ins_coin_fut]
        



@pytest.fixture(autouse=True)
def set_log_cap_level(caplog):
    caplog.set_level(logging.DEBUG)


@pytest.fixture
def client():
    return FakeClient(
        'ABCXYZ',
        ([(i, 1000) for i in range(30, 40)], [(i, 1000) for i in range(10, 21)]),
    )

class TestMethod:
    @pytest.fixture(scope="class")
    def monkeyclass(self):
        """Class scoped monkeypatch"""
        mpatch = MonkeyPatch()
        yield mpatch
        mpatch.undo

class TestSpot(TestMethod):
    @pytest.fixture
    def sb(self, monkeypatch, client):
        monkeypatch.setattr(SniperBot, 'exchange_name_of', lambda _, x: x)
        monkeypatch.setattr(SniperBot, 'exchange_id_of', lambda _, x: x)
        monkeypatch.setattr(SniperBot, 'name_of', lambda _, x: x)
        monkeypatch.setattr(SniperBot, 'is_futures_of', lambda _, account_id: False)
        monkeypatch.setattr(SniperBot, 'dual_side_position_of', lambda _, account_id: False)
        with SniperBot(
            [0], 'ABC', 'XYZ', -999, alt_client=client, logger=logging.getLogger()
        ) as sb:
            sb.delay = 0
            sb.config = {
                'totalAmount': 100,
                'minPrice': 20,
                'maxPrice': 29,
                'side': 'buy',
                'orderType': 'LIMIT',
                'maxSlippageThreshold': 0.05,
                'largeOrderThreshold': 10,
                'cumulativeOrderThreshold': -1,
            }
            yield sb

    def test_load_config(self, sb):
        sb.config = {
            'totalAmount': 100,
            'minPrice': -1,
            'maxPrice': -1,
            'side': 'buy',
            'orderType': 'LIMIT',
            'maxSlippageThreshold': 0.05,
            'largeOrderThreshold': 10,
            'cumulativeOrderThreshold': -1,
        }
        assert sb.max_price == math.inf
        logger.info(sb.config)
        assert sb.config
        assert sb.config_is_valid
        assert sb.pair == 'ABCXYZ'
        print(sb.client)
        assert sb.client
        assert sb.client.buy
        assert sb.client.sell
        assert sb.client.orderbook
        assert sb.orderbook
        assert sb.accounts == {0}


    def test_snipe_single_order(self, sb, client: FakeClient):
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '10',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        client.add_price_level(SELL, 25, 10)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCXYZ', 25, 10, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 90


    def test_no_snipe_order(self, sb, client):
        client.add_price_level(SELL, 25, 1)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled


    def test_low_account_balance(self, sb, client: FakeClient):
        low_balance = AccountBalance()
        low_balance['XYZ'].available = 25 * 9
        client.account_balance[0] = low_balance
        client.add_price_level(SELL, 25, 10)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled


    def test_cancel_order_on_failed(self, sb, client: FakeClient):
        client.order_results[0] = [
            {
                'state': 'AO',
                'dealt': '0',
                'remaining_amount': '10',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        client.add_price_level(SELL, 25, 10)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCXYZ', 25, 10, 0)]
        print(client.orders_canceled)
        assert len(client.orders_canceled) == 0
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 100


    def test_snipe_single_layer(self, sb, client: FakeClient):
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '100',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        client.add_price_level(SELL, 25, 200)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCXYZ', 25, 100, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 0
        assert sb.completed


    def test_snipe_multi_layer(self, sb, client: FakeClient):
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '100',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        client.add_price_level(SELL, 24, 5)
        client.add_price_level(SELL, 25, 200)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCXYZ', 25, 100, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 0
        assert sb.completed


    def test_multi_snipe_order(self, sb, client: FakeClient):
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '10',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        client.add_price_level(SELL, 25, 10)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCXYZ', 25, 10, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 90
        client.add_price_level(SELL, 24, 200)
        client.order_results[1] = [
            {
                'state': 'CO',
                'dealt': '90',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [
            (BUY, 'ABCXYZ', 25, 10, 0),
            (BUY, 'ABCXYZ', 24, 90, 1),
        ]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert len(sb.order_monitor.open_orders) == 0
        assert len(sb.order_monitor.completed_orders) == 2
        assert sb.completed
        sb.run()
        time.sleep(0.3)
        assert len(sb.order_monitor.open_orders) == 0
        assert len(sb.order_monitor.completed_orders) == 2


    def test_order_monitor_error_captured(self, monkeypatch, sb, client: FakeClient, caplog):
        def raise_error(*args, **kwargs):
            raise Exception('deliberate exception raised')

        client.order_results[0] = [
            {
                'state': 'AO',
                'dealt': '0',
                'remaining_amount': '10',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]

        client.add_price_level(SELL, 25, 200)
        sb.run()
        monkeypatch.setattr(Order, '__init__', raise_error)
        time.sleep(0.3)
        assert 'deliberate exception raised' in caplog.text


    def test_ignore_outdated_order_book(self, sb, client: FakeClient):
        client.order_results[0] = [
            {
                'account': 0,
                'state': 'FO',
                'dealt': '50',
                'remaining_amount': '0',
                # e.g. server time is 10s ahead for some reason
                'create_time': str(time.time() * 1000 + 10000),
                'update_time': str(time.time() * 1000 + 10000),
            }
        ]
        client.orders_placed = [(BUY, 'ABCXYZ', 25, 50, 0)]
        sb.order_monitor.add(0)
        client.add_price_level(SELL, 25, 200)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCXYZ', 25, 50, 0)]
        print(client.orders_canceled)
        assert not client.orders_canceled

#USD margin futures used here
class TestUsdMarginOneWayFutures(TestMethod):
    @pytest.fixture
    def sb(self, monkeypatch, client):
        monkeypatch.setattr(SniperBot, 'exchange_name_of', lambda _, x: x)
        monkeypatch.setattr(SniperBot, 'exchange_id_of', lambda _, account_id: 1)
        monkeypatch.setattr(SniperBot, 'name_of', lambda _, x: x)
        monkeypatch.setattr(SniperBot, 'is_futures_of', lambda _, account_id: True)
        monkeypatch.setattr(SniperBot, 'dual_side_position_of', lambda _, account_id: False)
        with SniperBot(
            [0], 'ABC', 'USDT', -999, alt_client=client, logger=logging.getLogger()
        ) as sb:
            sb.delay = 0
            sb.config = {
                'totalAmount': 1000,
                'minPrice': 20,
                'maxPrice': 29,
                'side': 'buy',
                'orderType': 'LIMIT',
                'maxSlippageThreshold': 0.05,
                'largeOrderThreshold': 100,
                'cumulativeOrderThreshold': -1,
            }
            yield sb

    def test_snipe_single_order(self, sb, client: FakeClient):
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '100',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        client.add_price_level(SELL, 25, 100)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCUSDT', 25, 100, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 900

    def test_margin_balance_open_long(self, sb, client: FakeClient):
        low_balance = AccountBalance()
        low_balance['USDT'].available = 25 * 10
        low_balance['ABCUSDT Short'].available = 0
        client.account_balance[0] = low_balance
        client.add_price_level(SELL, 25, 100)
        #leverage = 10
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled
        # increase margin
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '100',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        low_balance['USDT'].available = 25 * 10 + 1
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCUSDT', 25, 100, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 900

    def test_margin_balance_open_short(self, sb, client: FakeClient):
        sb.side = 'sell'
        low_balance = AccountBalance()
        low_balance['USDT'].available = 25 * 10
        low_balance['ABCUSDT Long'].available = 0
        client.account_balance[0] = low_balance
        client.add_price_level(BUY, 25, 100)
        #leverage = 10
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled
        # increase margin
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '100',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        low_balance['USDT'].available = 25 * 10 + 1
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(SELL, 'ABCUSDT', 25, 100, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 900

    def test_account_balance_open_long(self, sb, client: FakeClient):
        low_balance = AccountBalance()
        low_balance['USDT'].available = 0
        low_balance['ABCUSDT Short'].available = 100
        client.account_balance[0] = low_balance
        client.add_price_level(SELL, 25, 100)
        #leverage = 10
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled
        # increase margin
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '100',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        low_balance['ABCUSDT Short'].available = 100 + 1
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCUSDT', 25, 100, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 900

    def test_account_balance_open_short(self, sb, client: FakeClient):
        sb.side = 'sell'
        low_balance = AccountBalance()
        low_balance['USDT'].available = 0
        low_balance['ABCUSDT Long'].available = 100
        client.account_balance[0] = low_balance
        client.add_price_level(BUY, 25, 100)
        #leverage = 10
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled
        # increase margin
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '100',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        low_balance['ABCUSDT Long'].available = 100 + 1
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(SELL, 'ABCUSDT', 25, 100, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 900

#Coin margin futures used here
class TestCoinMarginTwoWayFutures(TestMethod):
    @pytest.fixture
    def sb(self, monkeypatch, client):
        monkeypatch.setattr(SniperBot, 'exchange_name_of', lambda _, x: x)
        monkeypatch.setattr(SniperBot, 'exchange_id_of', lambda _, account_id: 1)
        monkeypatch.setattr(SniperBot, 'name_of', lambda _, x: x)
        monkeypatch.setattr(SniperBot, 'is_futures_of', lambda _, account_id: True)
        monkeypatch.setattr(SniperBot, 'dual_side_position_of', lambda _, account_id: True)
        with SniperBot(
            [0], 'ABC', 'USD_PERP', -999, alt_client=client, logger=logging.getLogger()
        ) as sb:
            sb.delay = 0
            sb.config = {
                'totalAmount': 100,
                'minPrice': 20,
                'maxPrice': 29,
                'side': 'buy',
                'orderType': 'LIMIT',
                'maxSlippageThreshold': 0.05,
                'largeOrderThreshold': 10,
                'cumulativeOrderThreshold': -1,
            }
            yield sb

    def test_snipe_single_order(self, sb, client: FakeClient):
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '10',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        client.add_price_level(SELL, 25, 10)
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCUSD_PERP', 25, 10, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 90

    def test_margin_balance_open_long(self, sb, client: FakeClient):
        low_balance = AccountBalance()
        low_balance['ABC'].available = 0.4
        client.account_balance[0] = low_balance
        client.add_price_level(SELL, 25, 10)
        #leverage = 10
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled
        # increase margin
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '10',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        low_balance['ABC'].available = 0.41
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCUSD_PERP', 25, 10, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 90

    def test_margin_balance_open_short(self, sb, client: FakeClient):
        sb.side = 'sell'
        low_balance = AccountBalance()
        low_balance['ABC'].available = 0.4
        client.account_balance[0] = low_balance
        client.add_price_level(BUY, 25, 10)
        #leverage = 10
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled
        # increase margin
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '10',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        low_balance['ABC'].available = 0.41
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(SELL, 'ABCUSD_PERP', 25, 10, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 90

    def test_account_balance_close_long(self, sb, client: FakeClient):
        sb.side = 'sell'
        sb.order_type = 'LIMIT_CLOSE'
        low_balance = AccountBalance()
        low_balance['ABCUSD_PERP Long'].available = 10
        client.account_balance[0] = low_balance
        client.add_price_level(BUY, 25, 10)
        #leverage = 10
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled
        # increase margin
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '10',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        low_balance['ABCUSD_PERP Long'].available = 11
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(SELL, 'ABCUSD_PERP', 25, 10, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 90

    def test_account_balance_close_short(self, sb, client: FakeClient):
        sb.side = 'buy'
        sb.order_type = 'LIMIT_CLOSE'
        low_balance = AccountBalance()
        low_balance['ABCUSD_PERP Short'].available = 10
        client.account_balance[0] = low_balance
        client.add_price_level(SELL, 25, 10)
        #leverage = 10
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert not client.orders_placed
        print(client.orders_canceled)
        assert not client.orders_canceled
        # increase margin
        client.order_results[0] = [
            {
                'state': 'FO',
                'dealt': '10',
                'remaining_amount': '0',
                'create_time': str(time.time() * 1000),
                'update_time': str(time.time() * 1000),
            }
        ]
        low_balance['ABCUSD_PERP Short'].available = 11
        sb.run()
        time.sleep(0.3)
        print(client.orders_placed)
        assert client.orders_placed == [(BUY, 'ABCUSD_PERP', 25, 10, 0)]
        print(client.orders_canceled)
        print(sb.order_monitor.open_orders)
        print(sb.order_monitor.completed_orders)
        assert sb.remaining_amount == 90
