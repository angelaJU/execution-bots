.. Altonomy Legacy Bots documentation master file, created by
   sphinx-quickstart on Sun Sep 29 23:00:00 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Altonomy Legacy Bots' documentation!
=============================================
.. toctree::
   :glob:

   *

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
