Service
=========================

This module contains the service

.. automodule:: altonomy.legacy_bots.service
   :members: