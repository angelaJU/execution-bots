Config
=========================

This module contains the configurations

.. automodule:: altonomy.legacy_bots.config
   :members: