#!/bin/bash

# exit when any command fails
set -e

echo 'No test'
